![](data:image/png;base64...)
**Cloud Security Posture Management**

**Runbook – Remediation**

|  |  |  |
| --- | --- | --- |
| **Control Id** | **Control Name** | **Severity** |
| **IAM**-**001** | [*IAM User should not have any policies attached*](https://app.wiz.io/policies/cloud-configuration-rules#%7E%28filters%7E%28search%7E%28contains%7E%27IAM*20User*20should*20not*20have*20any*20policies*20attached%29%29%7EcloudConfigurationRule%7E%272f46b6de-45b4-4c85-9c0b-ead33074c760%29) | **Medium** |

Version 1.0

Table of Content

[1. Overview 3](#_Toc1585623523)

[DescriptionThis control evaluates whether an IAM user has any IAM policies (managed or inline) attached. IAM users without required governance or review can introduce security and audit risks, especially when permissions are assigned without visibility or approval. 3](#_Toc660752008)

[The rule passes when: 3](#_Toc677437088)

[This ensures that any IAM user with permission is explicitly identified and reviewed, preventing unauthorized, accidental, or non-compliant access. 3](#_Toc1851357924)

[2. Objective 3](#_Toc1321373911)

[3. Triage Process 3](#_Toc1995996156)

[3.1 Identify Affected Users (Wiz) 3](#_Toc1367011377)

[3.2 Categorize Users 4](#_Toc521340039)

[4. Manual Mitigation – AWS Console 4](#_Toc1548143078)

[4.1 4](#_Toc1688641899)

[4.3. Delete IAM User (Only If Fully Approved) 5](#_Toc15572483)

[5. Mitigation – AWS CLI 5](#_Toc1026993071)

[5.1 List attached to managed policies 5](#_Toc1213834407)

[5.2 List inline policies 5](#_Toc1057951476)

[5.3 Detach managed policy 5](#_Toc716426776)

[6.1 Update IAM Policy Using CloudFormation 5](#_Toc1370762119)

[Ensure that IAM policies do not include wildcard permissions for both Action and Resource. 5](#_Toc1435388290)

[6.2 Recommended CloudFormation Workflow 6](#_Toc522378684)

[Result 6](#_Toc1777728182)

[7: Document Exception 6](#_Toc1478052785)

[8. Preventive Control 6](#_Toc1837505957)

[9. Validation and Success Criteria 6](#_Toc1375926627)

# 1. Overview

**Detection Tool:** Wiz Cloud Security Platform

**Hyperlink to the Rule:** [Cloud Configuration Rules – Wiz](https://app.wiz.io/policies/cloud-configuration-rules#%7E%28cloudConfigurationRule%7E%273ff7127e-0a07-4082-80df-02db44058080%29)

**Rule Type:** Wiz Custom Configuration Rule

# **Description** This control evaluates whether an IAM user has any IAM policies (managed or inline) attached. IAM users without required governance or review can introduce security and audit risks, especially when permissions are assigned without visibility or approval.

# The rule passes when:

* No managed policies are attached (AttachedManagedPolicies is empty), and
* No inline policies exist (UserPolicyList is empty).

The rule fails when:

* At least one IAM policy (managed or inline) is attached to the IAM user.

# This ensures that any IAM user with permission is explicitly identified and reviewed, preventing unauthorized, accidental, or non-compliant access.

# 2. Objective

The objective of this control is to identify IAM users that have IAM policies attached, ensuring visibility and governance over user permissions. This helps security teams validate whether:

* The IAM user is intentionally permissioned,
* The attached policies are approved and least privileged, or
* The user should be remediated, restricted, or removed.

# 3. Triage Process

Please Refer to the below mentioned document:

[Master+Template+-+Remediation+SOP.docx](https://cargillonline.sharepoint.com/%3Aw%3A/r/sites/GIS-ADC-CloudSecurityTeam-TeamDiscussions-Private/_layouts/15/Doc.aspx?sourcedoc=%7B78D12AE6-08C4-4A84-AB4A-348A3A0F0F82%7D&file=Master%2BTemplate%2B-%2BRemediation%2BSOP.docx&action=default&mobileredirect=true)

## 3.1 Identify Affected Users (Wiz)

* Navigate to Wiz → Cloud Configuration Findings
* Filter by rule “IAM User should not have any policies attached”
* Export the list of failed IAM users Collect the following details:

Collect the following details:

* IAM username
* AWS account ID
* Policy type (Managed / Inline)
* Policy name(s)
* User creation date
* User owner or application tag

## 3.2 Categorize Users

Category A: Approved & Valid

* Users with approved access
* Policies aligned with business need

Category B: Requires Review

* Over permissioned users
* Legacy or shared users
* Policies attached without approval evidence

Category C – Not Required

* Test, demo, or temporary users
* Users with unnecessary permissions

***Note : Confirm the*** ***user purpose, owner, access method (console or programmatic), attached permissions, and MFA status before*** ***taking action.***

## 4. Manual Mitigation – AWS Console

4.1 **Validate Policy Requirement**:

Use this step when the IAM user is expected to exist.

* Navigate to AWS Console → IAM → Users
* Select the affected IAM user
* Review of the Permissions tab
* Confirm whether attached policies are:

Approved

Required

Leastprivileged

Post-action:

* Monitor for 7–14 days
* Document any service impact
* Proceed to further actions if no issues are observed

Result:

* If valid → Document approval
* If not required → Proceed to removal

4.2: Remove IAM Policies
Use this step when policies are not required.

Managed Policies

* Detach the managed policy from the IAM user

Inline Policies

* Delete the inline policy attached to the user

Result:

* IAM users have no policies attached
* Wiz finding is resolved

### 4.3. Delete IAM User (Only If Fully Approved)

Delete the user only when:

* No business requirement exists
* User is not actively used
* Owner approval is obtained

**High-level console steps:**

* Detach managed policies
* Delete inline policies Remove access keys
* Disable console access
* Delete the IAM user

### 5. Mitigation – AWS CLI

### 5.1 List attached to managed policies

|  |
| --- |
| *aws iam list-attached-user-policies --**user-name <USERNAME>* |

### 5.2 List inline policies

|  |
| --- |
| *aws iam list-user-policies --**user-name <USERNAME>* |

### 5.3 Detach managed policy

|  |
| --- |
| *aws iam detach-user-policy --**user-name <USERNAME> --policy-arn <POLICY\_ARN>* |

5.4 Delete inline policy

|  |
| --- |
| *aws iam delete-user-policy --**user-name <USERNAME> --policy-name <POLICY\_NAME>* |

6. Mitigation Using AWS CloudFormation
AWS CloudFormation should be used when IAM users and policies are managed as Infrastructure as Code.

Remediation is enforced by updating the IAM policy definition to remove full administrative access.

### 6.1 Update IAM Policy Using CloudFormation

### Ensure that IAM policies do not include wildcard permissions for both Action and Resource.

|  |
| --- |
| Resources:  RestrictedIAMPolicy:  Type: AWS::IAM::Policy  Properties:  PolicyName: Restricted-IAM-Policy  PolicyDocument:  Version: "2012-10-17"  Statement:  - Effect: Allow  Action:  - s3:GetObject  Resource:  - arn:aws:s3:::example-bucket/\*  Users:  - ExampleUser |

Key Remediation Actions:

* Remove "Action": "\*"
* Remove "Resource": "\*"
* Define only required services and actions
* Scope resources wherever possible

### 6.2 Recommended CloudFormation Workflow

* Wiz identifies IAM policies with full administrative access
* Security validates business requirement
* CloudFormation template updated to restrict permissions
* Change reviewed and approved
* Stack update applied to enforce compliance

## Result

* Full administrative access is removed
* IAM policy follows least privilege
* Wiz finding is resolved
* CloudFormation enforces compliance

## 7: Document Exception

Use this section when an IAM policy must temporarily retain full administrative access for valid business or operational reasons.

**Required Exception Documentation (In Progress):** TBD

* Business justification
* Policy name and AWS account ID
* Approver name and approval date
* Exception expiry or review date
* Compensating controls (MFA, monitoring, logging)

In Wiz: Add exception notes to the finding and set a periodic review reminder.

## 8. Preventive Control

* Ensure policies are attached only after approval
* Prefer IAM roles over IAM users
* Periodically review IAM users with permissions

## 9. Validation and Success Criteria

The control is considered effective when:

* No IAM users have unapproved policies attached
* Wiz findings are reviewed and documented
* IAM permissions are traceable to business justification
* Continuous visibility through Wiz compliance checks