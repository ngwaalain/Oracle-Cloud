![](data:image/png;base64...)

**Cloud Security Posture Management**

**Runbook – Remediation**

|  |  |  |
| --- | --- | --- |
| **Control Id** | **Control Name** | **Severity** |
| IAM-025 | [*IAM policy should not have full administrative access*](https://app.wiz.io/policies/cloud-configuration-rules#%7E%28filters%7E%28search%7E%28contains%7E%27IAM-025%29%29%7EcloudConfigurationRule%7E%277e102b77-befe-47ba-9d80-5f0498726725%29) | Medium |

Version 1.0

# Table of Content

[1. Overview 2](#_Toc1062509085)

[Description: 2](#_Toc852941116)

[3. Triage Process 3](#_Toc1526204933)

[3.1 Identify Affected Policies (Wiz) 4](#_Toc69018987)

[3.2 Categorize Findings 4](#_Toc1383685690)

[4. Manual Mitigation – AWS Console 4](#_Toc820311944)

[4.1 Review Policy Permissions 4](#_Toc1123344540)

[4.2 Restrict Permissions 5](#_Toc1006310908)

[4.3 Delete Policy (Only If Fully Approved) 5](#_Toc731546699)

[5. Mitigation – AWS CLI 5](#_Toc1848600377)

[6. Mitigation Using Terraform (IaC) 5](#_Toc884064797)

[7. Document Exception (Status: TBD) 6](#_Toc797170564)

[8. Preventive Control 6](#_Toc1015716227)

[9. Validation and Success Criteria 6](#_Toc2084651542)

# 1. Overview

**Detection Tool:** Wiz Cloud Security Platform

**Hyperlink to the Rule:** [Cloud Configuration Rules – Wiz](https://app.wiz.io/policies/cloud-configuration-rules#%7E%28cloudConfigurationRule%7E%273ff7127e-0a07-4082-80df-02db44058080%29)

**Rule Type:** Wiz Custom Configuration Rule

Description:

This control evaluates whether **IAM customer‑managed or inline policies grant unrestricted administrative privileges** across the AWS environment, in violation of the Principle of Least Privilege (PoLP).

The rule fails when an IAM policy statement contains all of the following:

* Effect: "Allow"
* Action: "\*"
* Resource: "\*"

Such policies effectively grant **full administrative access** to all AWS services and resources without restriction. This level of access bypasses role based separation of duties, increases the blast radius of credential compromise, and makes it difficult to enforce accountability or trace actions.

Policies with full administrative access may be created intentionally for convenience, legacy requirements, or rapid troubleshooting; however, their continued use introduces significant security and compliance risk.

This control helps ensure that:

* Permissions are explicitly scoped to required services, actions, and resources
* Access aligns with the Principle of Least Privilege
* Over permissioned policies are identified and reviewed
* Unauthorized privilege escalation paths within the AWS environment are minimized
* Auditability, governance, and separation of duties are maintained

By detecting and remediating overly permissive IAM policies, this control reduces the likelihood of accidental misuse, malicious exploitation, and large-scale security incidents.

2. Objective

The objective of this control is to identify, assess, and remediate IAM policies that grant full administrative or unrestricted access across cloud environments. Such broad permissions significantly increase the risk of unauthorized actions, privilege misuse, and non-compliance with security and audit requirements.

This control ensures that:

* IAM permissions are explicitly scoped to required services, resources, and actions based on business and operational needs.
* Over-permissioned or overly broad access (for example, wildcard actions or resources) is systematically reviewed, validated, and reduced where not justified.
* Access rights are continuously aligned with the principle of least privilege, ensuring identities have only the minimum permissions necessary to perform their intended functions.
* IAM policies meet security governance, compliance, and audit expectations, supporting traceability, accountability, and periodic access reviews.

By enforcing this control, the organization minimizes the attack surface, reduces the risk of privilege escalation, and maintains stronger control over administrative access in accordance with internal security standards and regulatory requirements.

# 3. Triage Process

Please Refer to the below mentioned document:[Master+Template+-+Remediation+SOP.docx](https://cargillonline.sharepoint.com/%3Aw%3A/r/sites/GIS-ADC-CloudSecurityTeam-TeamDiscussions-Private/_layouts/15/Doc.aspx?sourcedoc=%7B78D12AE6-08C4-4A84-AB4A-348A3A0F0F82%7D&file=Master%2BTemplate%2B-%2BRemediation%2BSOP.docx&action=default&mobileredirect=true)

## 3.1 Identify Affected Policies (Wiz)

* Navigate to Wiz → Cloud Configuration Findings
* Filter by rule “IAM policy should not have full administrative access”
* Identify impacted:
  i> IAM users, roles, or groups
  ii> Policy type (Managed / Inline)
  iii> Policy name
  iv> Attached principal (User / Role / Group)

## 3.2 Categorize Findings

**Category A – Approved & Controlled**

i>Temporary admin access
ii>Break‑glass or emergency roles
iii>Approval documented

**Category B – Requires Remediation**

i>Overpermissive policies
ii>Broad permissions no clear justification
iii>Legacy admin access

**Category C – Not Required**

* Legacy or unused policies
* Excessive permissions without business need

***Note:*** *Always validate business purpose, approval, usage pattern, and attached principals before remediation.*

# 4. Manual Mitigation – AWS Console

## 4.1 Review Policy Permissions

* Navigate to AWS Console → IAM → Policies
* Open the affected policy
* Review policy statements for:
  i>Action: "\*"
  ii>Resource: "\*"

## 4.2 Restrict Permissions

Replace wildcard permissions with:

* Specific AWS services
* Required actions only
* Scoped resources where possible

**Result:**

* Policy follows least privilege
* Full admin access is removed
* Wiz finding is resolved

### 4.3 Delete Policy (Only If Fully Approved)

Delete the policy only when:

* No business requirement exists
* Policy is unused
* Owner approval is obtained

# 5. Mitigation – AWS CLI

1. ***Get policy versions***

|  |
| --- |
| **aws iam get-policy-version \** **--policy-arn <POLICY\_ARN> \** **--version-id <VERSION\_ID>** |

1. *Create a new restricted policy version and set it as default*

|  |
| --- |
| aws iam create-policy-version --policy-arn <POLICY\_ARN> --policy-document file://policy.json --set-as-default |

# 6. Mitigation Using Terraform (IaC)

When IAM policies are managed via Terraform, update the policy definition:

|  |
| --- |
| resource "aws\_iam\_policy" "restricted\_policy" {    policy = jsonencode({      Version = "2012-10-17"      Statement = [{        Effect   = "Allow"        Action   = ["s3:GetObject"]        Resource = ["arn:aws:s3:::example-bucket/\*"]      }]    }) } |

**Result:**

* Admin-level access removed.
* Terraform enforces least privilege
* Wiz finding is resolved

# 7. Document Exception (Status: TBD)

Use this section only if full administrative access is required.

Required Details

* Business Justification: Clear justification explains why full administrative access is required.
* Policy Name and AWS Account ID: The exact IAM policy name and the associated AWS account ID.
* Approver Name and Approval Date Name of the authorized approvers and date of approval.
* Expiry or Review Date Defined expiry date or periodic review date for the exception.
* Compensating Controls

Details of compensating controls in place, such as:

* Multi‑Factor Authentication (MFA)
* Enhanced logging and monitoring

# 8. Preventive Control

* Avoid wildcard permissions in IAM policies
* Enforce PoLP via policy reviews
* Prefer scoped roles over admin policies
* Periodically review IAM policies using Wiz

# 9. Validation and Success Criteria

The control is effective when:

* No IAM policies grant unrestricted admin access
* Wiz findings are reviewed and all admin access is approved and documented
* Permissions are traceable to business justification