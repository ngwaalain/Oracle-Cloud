![](data:image/png;base64...)

**Cloud Security Posture Management**

**Runbook – Remediation**

|  |  |  |
| --- | --- | --- |
| **Control Id** | **Control Name** | **Severity** |
| **IAM-047** | **Access keys unused for 30 days or more should be disabled** | **Medium** |

Version 1.0

# Table of Contents

[Table of Contents 1](#_Toc1769169020)

[1. Overview 1](#_Toc1976328862)

[2. Objective 1](#_Toc488868333)

[3. Triage Process:Please Refer to the below mentioned document: 2](#_Toc2023948746)

[4. Manual Mitigation – AWS Console 2](#_Toc70801970)

[4.1 Deactivate Unused Access Keys (Recommended) 2](#_Toc1300718873)

[5. Mitigation – AWS CLI 3](#_Toc1594296837)

[6. Mitigation Using Terraform (IaC) 3](#_Toc184479381)

[7. Mitigation Using CloudFormation (IaC) 4](#_Toc859604589)

[8. Document Exception 4](#_Toc1506426528)

[9. Preventive Control – AWS Config 5](#_Toc539686315)

[10. Validation and Success Criteria 5](#_Toc361771388)

# 1. Overview

**Detection Tool**: Wiz Cloud Security Platform
**Hyperlink to the rule**: [Cloud Configuration Rules | Wiz](https://app.wiz.io/policies/cloud-configuration-rules#%7E%28filters%7E%28search%7E%28contains%7E%27IAM-047%29%7EserviceType%7E%28equals%7E%28%7E%27AWS%29%29%29%7EcloudConfigurationRule%7E%27daf2c5aa-2bab-45f8-84f1-2ce3158b770d%29)
**Severity**: Medium

**Description:**

This control identifies IAM access keys that have not been used for 30 days and flags them for remediation. Disabling inactive access keys reduces the risk of credential misuse, key leakage, and unauthorized access, while reinforcing least‑privilege and access hygiene practices.

## 2. Objective

This runbook defines the standardized process to identify, manually remediate, and prevent IAM user access keys that have been unused for 30 days or more, reducing the risk of credential misuse, key leakage, and unauthorized access.

## 3. Triage Process: Please Refer to the below mentioned document:

[Master+Template+-+Remediation+SOP.docx](https://cargillonline.sharepoint.com/%3Aw%3A/r/sites/GIS-ADC-CloudSecurityTeam-TeamDiscussions-Private/_layouts/15/Doc.aspx?sourcedoc=%7B78D12AE6-08C4-4A84-AB4A-348A3A0F0F82%7D&file=Master%2BTemplate%2B-%2BRemediation%2BSOP.docx&action=default&mobileredirect=true)

**3.1 Identify Affected Users (Wiz)**

Navigate to Wiz → Cloud Configuration Findings.
Filter by the rule 'Access keys unused for 30 days or more should be disabled'.
Export the list of impacted IAM users.

Collect the following details:
- IAM username
- AWS account ID
- Access key ID
- Access key last-used date
- User creation date
- Resource ownership tags

**3.2 Categorize Users**

Category A – Safe to Disable: Test, demo, temporary, or decommissioned users
Category B – Requires Investigation: Service accounts, shared users, automation users, or unclear ownership
Category C – Business-Critical (Exceptions): Audit-mandated users or formally approved exceptions

Note: Always confirm the user purpose, owner, permissions, and workload dependency before disabling any access key.

## 4. Manual Mitigation – AWS Console

4.1 Deactivate Unused Access Keys (Recommended)
Steps:
1. AWS Console → IAM → Users
2. Select impacted user
3. Open Security credentials tab
4. Identify keys unused ≥ 30 days
5. Select key → Deactivate

Post-action:
- Monitor for 7–14 days
- Validate no service impact

Result:
- Access key becomes Inactive
- IAM user unchanged

**4.2 Delete Access Keys (Only If Approved)**
Delete only after business approval and validation.

## 5. Mitigation – AWS CLI

**Disable Access Key:**

|  |
| --- |
| ***aws iam update-access-key*** *--****user-name <USERNAME> --access-key-id <ACCESS\_KEY\_ID> --status Inactive*** |

**Delete Access Key**:

|  |
| --- |
| ***aws iam delete-access-key --user-name <USERNAME> --access-key-id <ACCESS\_KEY\_ID>*** |

## 6. Mitigation Using Terraform (IaC)

1. **Terraform enforces remediation by removing the access key resource**.

|  |
| --- |
| ***resource "aws\_iam\_access\_key" "this" {***  ***count = var.create\_access\_key ? 1 : 0***  ***user = aws\_iam\_user.this.name*** ***}*** |

Setting count = 0 removes unused keys.

1. **Workflow:**

1. Wiz identifies unused access keys

2. Security validates ownership and impact

1. Terraform variables are updated
2. terraform plan is reviewed and approved
3. terraform apply enforces remediation

## 7. Mitigation Using CloudFormation (IaC)

CloudFormation enforces remediation using automated workflows (Lambda/SSM) to disable unused access keys

|  |
| --- |
| ***Resources:***    ***AccessKeyCleanupLambda:***  ***Type: AWS::Lambda::Function***  ***Properties:***  ***Runtime: python3.9***  ***Handler: index.lambda\_handler***  ***Role: !GetAtt LambdaExecutionRole.Arn***  ***Timeout: 300***  ***Code:***  ***ZipFile: |***  ***import boto3***  ***from datetime import datetime, timezone***    ***iam = boto3.client('iam')***  ***THRESHOLD\_DAYS = 30***    ***def lambda\_handler(event, context):***  ***users = iam.list\_users()['Users']***  ***for user in users:***  ***uname = user['UserName']***  ***keys = iam.list\_access\_keys(UserName=uname)['AccessKeyMetadata']***    ***for key in keys:***  ***key\_id = key['AccessKeyId']*** |

**Workflow:**

1. Wiz identifies unused access keys
2. Security validates ownership and impact
3. CloudFormation deploys automation (Lambda/SSM) for remediation
4. Event Bridge triggers periodic evaluation
5. Unused access keys (≥30 days) are automatically disabled
6. Notifications and grace period can be applied before deletion

## 8. Document Exception

Required:
- Business justification
- Approver
- Expiry date
- Compensating controls

Document exceptions in Wiz and review periodically.

## 9. Preventive Control – AWS Config

Enable AWS managed rule iam-user-unused-credentials-check with MaximumCredentialUsageAge = 30 days.

**Steps:**

1. Navigate to **AWS Config**
2. Select **Add Rule → AWS Managed Rule**
3. Choose **iam-user-unused-credentials-check**
4. Set **MaximumCredentialUsageAge = 30 days**
5. Save and enable the rule

**Result:**

* Continuous detection
* Audit-ready evidence
* Reduced recurrence

## 10. Validation and Success Criteria

- Reduced Wiz findings
- No workload disruption
- Continuous compliance visibility