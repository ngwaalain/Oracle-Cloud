![](data:image/png;base64...)

**Cloud Security Posture Management**

**Runbook – Remediation**

|  |  |  |
| --- | --- | --- |
| **Control Id** | **Control Name** | **Severity** |
| **EBS-008** | **EBS Snapshots Block Public Sharing should be enabled in all regions** | **Medium** |

Version 1.0

**Table of Contents**

[1. Overview 2](#_Toc228219516)

[2. Description: 3](#_Toc228219517)

[3. Objective 3](#_Toc228219518)

[4. Triage Process 3](#_Toc228219519)

[4.1. Identify Affected Regions (Wiz) 3](#_Toc228219520)

[4.2. Categorize Findings 4](#_Toc228219521)

[5. Manual Mitigation – AWS Console 4](#_Toc228219522)

[6. – AWS CLI 4](#_Toc228219523)

[7. Mitigation Using Terraform (IaC) 4](#_Toc228219524)

[7.1. Recommended Terraform Workflow 5](#_Toc228219525)

[8. Mitigation Using CloudFormation (IaC) 5](#_Toc228219526)

[8.1. Remove Access Keys Using CloudFormation 5](#_Toc228219527)

[8.2. Recommended CloudFormation Workflow 5](#_Toc228219528)

[9. Document Exception 6](#_Toc228219529)

[10. Detective Control 6](#_Toc228219530)

[11. Validation and Success Criteria 6](#_Toc228219531)

# Overview

**Detection Tool:** Wiz Cloud Security Platform
**Hyperlink to the Rule:** [Cloud Configuration Rules | Wiz](https://app.wiz.io/policies/cloud-configuration-rules#%7E%28filters%7E%28search%7E%28contains%7E%27EBS*20Snapshots*20Block*20%29%7EserviceType%7E%28equals%7E%28%7E%27AWS%29%29%29%7EcloudConfigurationRule%7E%27330a69a2-348c-4f46-949f-349844a02d32%29)
**Detective Control**: NA

# Description:

This control identifies AWS accounts where **Block Public Access for EBS snapshots is disabled in one or more regions**. When this protection is not enabled, users can unintentionally or intentionally make EBS snapshots publicly accessible, exposing sensitive data such as application files, credentials, operating system images, or database contents. Block Public Sharing for EBS snapshots is a regional, account‑level security control. If not enforced consistently across all regions, the account remains vulnerable to data leakage through publicly shared snapshots.

# Objective

The objective of this runbook is to define a standardized process to **identify, review, and enforce Block Public Access for Amazon EBS snapshots across all AWS regions**, as detected by the Wiz Cloud Security Platform.

This runbook enables security and cloud operations teams to:

* Identify regions where snapshot public sharing is not blocked
* Safely enable preventive controls without impacting workloads
* Enforce the setting using Infrastructure as Code (IaC)
* Ensure ongoing protection against accidental snapshot exposure

The goal is to ensure that **no EBS snapshot can be publicly shared**, thereby reducing the risk of data exposure and strengthening the overall AWS security posture.

# Triage Process

**Please Refer to the below mentioned document:**

[Master+Template+-+Remediation+SOP.docx](https://cargillonline.sharepoint.com/%3Aw%3A/r/sites/GIS-ADC-CloudSecurityTeam-TeamDiscussions-Private/_layouts/15/Doc.aspx?sourcedoc=%7B78D12AE6-08C4-4A84-AB4A-348A3A0F0F82%7D&file=Master%2BTemplate%2B-%2BRemediation%2BSOP.docx&action=default&mobileredirect=true)

## Identify Affected Regions (Wiz)

Navigate to Wiz → Cloud Configuration Findings and filter by the rule **“EBS Snapshots Block Public Sharing is disabled”**.

Identify the AWS account and regions where the setting is reported as disabled.

Collect the following details:

* AWS account ID
* Affected region(s)
* Current snapshot block public access state

## Categorize Findings

* **Category A – Safe to Remediate:** Non‑production or production regions with no public snapshot sharing requirement
* **Category B – Requires Investigation:** Regions with legacy operational practices or unclear ownership
* **Category C – Business‑Critical (Exceptions):** Regions requiring temporary public snapshot sharing with approved exception

**Note:** This control is preventive and does not impact running workloads.

# Manual Mitigation – AWS Console

1. Log in to the AWS Management Console
2. Navigate to **EC2 → Snapshots → Account Attributes**
3. Select **Block Public Access for Snapshots**
4. Choose **Block all sharing**
5. Apply the setting for the selected region

**Result:**

* Public snapshot sharing is fully blocked
* Existing public snapshots become non‑public

# AWS CLI

**Enable Block Public Sharing (All Sharing):**

|  |
| --- |
| *aws ec2 enable-snapshot-block-public-access \*  *--state block-all-sharing \*  *--region <REGION>* |

**Verify setting:**

|  |
| --- |
| *aws ec2 get-snapshot-block-public-access-state --region <REGION>* |

# Mitigation Using Terraform (IaC)

Terraform should be used when AWS account‑level controls are managed as Infrastructure as Code. This ensures consistent enforcement across regions and environments.

**Enable Block Public Sharing Using Terraform:**

|  |
| --- |
| *resource "aws\_ebs\_snapshot\_block\_public\_access" "this" {*  *state = "block-all-sharing"*  *}* |

## Recommended Terraform Workflow

1. Wiz identifies unused credentials.
2. The security team validates the impact.
3. Terraform variables are updated to disable console access or remove access keys.
4. The terraform plan is reviewed and approved.
5. terraform apply enforces the change.

# Mitigation Using CloudFormation (IaC)

CloudFormation can be used to enforce snapshot public access controls at the account and regional level.

**Enable Block Public Sharing Using CloudFormation:**

|  |
| --- |
| Resources:          EbsSnapshotBlockPublicAccess:          Type: AWS::EC2::SnapshotBlockPublicAccess          Properties:          State: block-all-sharing |

## Recommended CloudFormation Workflow

1. Wiz identifies non‑compliant regions
2. Security team validates
3. CloudFormation template is updated
4. Change set is reviewed and executed

# Document Exception

**"TB**D"
Use only when public snapshot sharing is required for a valid business reason.

- Business justification
- Approved region and duration
- Approver name and date
- Compensating controls and review schedule

# Detective Control

AWS does not provide an AWS Config managed rule to enforce this control globally. Detection relies on AWS EC2 snapshot account‑level settings analyzed by the Wiz Cloud Security Platform.

# Validation and Success Criteria

Successful remediation is indicated by:

* Wiz finding marked as resolved
* Block Public Sharing enabled in all regions
* No ability to publicly share EBS snapshots