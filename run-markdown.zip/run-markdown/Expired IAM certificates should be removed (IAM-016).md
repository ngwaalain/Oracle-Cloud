![A green leaf on a black background

AI-generated content may be incorrect.](data:image/png;base64...)

**Cloud Security Posture Management**

**Runbook – Remediation**

|  |  |  |
| --- | --- | --- |
| **Control Id** | **Control Name** | **Severity** |
| **IAM-016** | **Expired IAM certificates should be removed** | **Low** |

Version 1.0

Table of Contents

[1. Overview 3](#_Toc229585569)

[2. Objective 3](#_Toc229585570)

[3. Triage Process 4](#_Toc229585571)

[3.1 Identify Affected Certificates (Wiz) 4](#_Toc229585572)

[3.2 Validate Certificate Usage 4](#_Toc229585573)

[3.3 Prerequisites 4](#_Toc229585574)

[4. Manual Mitigation – AWS Console 5](#_Toc229585575)

[4.1 Verify the certificate is in use: 5](#_Toc229585576)

[4.2 Remove the dependencies: 5](#_Toc229585577)

[4.3 Delete the certificate is expired: 5](#_Toc229585578)

[5. Mitigation – AWS CLI 5](#_Toc229585579)

[5.1 Verify the certificate status 5](#_Toc229585580)

[5.2 Certificate Usage 5](#_Toc229585581)

[5.3 Remove expired certificate 6](#_Toc229585582)

[5.4 Verify certificate 6](#_Toc229585583)

[6: Mitigation Using CloudFormation (IaC) 6](#_Toc229585584)

[7: Mitigation Using Terraform (IaC) 6](#_Toc229585585)

[7.1 Remove Expired IAM Certificates Using Terraform 7](#_Toc229585586)

[8: Document Exception 8](#_Toc229585587)

[9. Preventive Control – AWS Config Managed Rule 8](#_Toc229585588)

[10. Validation and Success Criteria 8](#_Toc229585589)

## 1. Overview

**Detection Tool**: Wiz Cloud Security Platform

**Rule Name**: Expired IAM certificates should be removed (LEGACY MODEL)

**Hyperlink to the Rule**: [Cloud Configuration Findings | Wiz](https://app.wiz.io/findings/configuration-findings/cloud#%7E%28filters%7E%28status%7E%28equals%7E%28%7E%27OPEN%29%29%7Erule%7E%28equals%7E%28%7E%27e61d4129-4325-41b2-8b82-c53e32f357bc%29%29%29%7Eentity%7E%28%7E%29%7EcloudConfigurationRule%7E%27e61d4129-4325-41b2-8b82-c53e32f357bc%29)

**Description**

This control identifies expired IAM server certificates that are still present in AWS accounts under the legacy IAM server certificate model. Although expired certificates can no longer be used for authentication, their continued presence indicates poor credential lifecycle management and increases operational and security risk.

Expired certificates may:

* Cause confusion during certificate rotation
* Be mistakenly re referenced by legacy services
* Obscure visibility into active certificate usage
* Contribute to audit and compliance findings

AWS recommends removing expired IAM certificates once they are no longer in use. This metric ensures that only valid, required certificates remain in the IAM inventory.

This control is detective in nature, as AWS does not automatically remove expired IAM certificates. Wiz continuously evaluates IAM server certificates to detect expiration and generate findings for remediation.

## 2. Objective

To identify and remove the expired IAM signing certificates from IAM users using AWS.

The objective of this runbook is to define a standardized remediation process for expired IAM server certificates identified by the Wiz Cloud Security Platform.

Retaining expired certificates:

* Increases configuration clutter
* Introducing operational ambiguity
* Violates certificate lifecycle and hygiene best practices

This runbook provides guidance to:

* Validate expired certificate findings
* Ensure certificates are not referenced by active resources
* Safely deleted expired IAM certificates
* Manage approved exceptions with proper documentation

The goal is to maintain a clean and accurate IAM certificate inventory, reducing security and audit risk.

## 3. Triage Process

Please Refer to the below mentioned document:

[[Master+Template+-+Remediation+SOP.docx](https://cargillonline.sharepoint.com/%3Aw%3A/r/sites/GIS-ADC-CloudSecurityTeam-TeamDiscussions-Private/_layouts/15/Doc.aspx?sourcedoc=%7B78D12AE6-08C4-4A84-AB4A-348A3A0F0F82%7D&file=Master%2BTemplate%2B-%2BRemediation%2BSOP.docx&action=default&mobileredirect=true)](https://cargillonline.sharepoint.com/%3Aw%3A/r/sites/GIS-ADC-CloudSecurityTeam-TeamDiscussions-Private/_layouts/15/Doc.aspx?sourcedoc=%7B78D12AE6-08C4-4A84-AB4A-348A3A0F0F82%7D&file=Master%2BTemplate%2B-%2BRemediation%2BSOP.docx&action=default&mobileredirect=true)

### 3.1 Identify Affected Certificates (Wiz)

Navigate to Wiz → Cloud Configuration Findings and filter by the rule “Expired IAM certificates should be removed”. Export the list of affected details.

Collect the following details:

* Certificate name
* AWS account ID
* Expiration date
* Certificate upload date
* Associated tags (if any)

### 3.2 Validate Certificate Usage

Before deletion, confirm:

* The certificate is expired
* The certificate is not referenced by:

1. Elastic Load Balancers (Classic ELB)
2. Legacy CloudFront configurations
3. Any custom or legacy integrations

Note: Deleting an actively referenced certificate may result in service disruption.

### 3.3 Prerequisites

The user should have the below stated permission to do changes to access keys.

IAM permissions:

|  |
| --- |
| iam:ListSigningCertificates  iam:DeleteSigningCertificates |

## 4. Manual Mitigation – AWS Console

### 4.1 Verify the certificate is in use:

This action is safe, and low risk

**Step 1**: Navigate to AWS Console → IAM → Server Certificates (Legacy Model Login)

**Step 2**: Review certificate →Expiration details

**Step 3**: Certificate Name → check the certificate associated with any of the below

* Load Balancers (ELB/ALB)
* CloudFront distributions
* API Gateway custom domains
* Other AWS services

### 4.2 Remove the dependencies:

**Step 1**: Replace the certificate with a new one

**Step 2**: Update the service configuration with new certificates

### 4.3 Delete the certificate is expired:

Server Certificates→Certificate\_Name→Check the expiry →Delete.

## 5. Mitigation – AWS CLI

5.1 Verify the certificate status:

|  |
| --- |
| aws iam get-server-certificate --server-certificate-name <CERTIFICATE-NAME> |

5.2 Certificate Usage:

# Check if certificate is used by CloudFront distributions

|  |
| --- |
| aws cloudfront list-distributions –query 'DistributionList.Items[?ViewerCertificate.IAMCertificateId==` <CERTIFICATE-NAME> `]' |

# Check if certificate is used by ELB Classic Load Balancers

|  |
| --- |
| aws elb describe-load-balancers --query 'LoadBalancerDescriptions[?ListenerDescriptions[?Listener.SSLCertificateId==`arn:aws:iam::AWS-ACCOUNT-NUMBER:server-certificate/<CERTIFICATE-NAME>`]]' |

# Check if certificate is used by Application Load Balancers

|  |
| --- |
| aws elbv2 describe-listeners --query 'Listeners[?Certificates[?CertificateArn==`arn:aws:iam:: AWS-ACCOUNT-NUMBER:server-certificate/<CERTIFICATE-NAME>`]]' |

5.3 Remove expired certificate:

|  |
| --- |
| aws iam delete-server-certificate --server-certificate-name <CERTIFICATE-NAME> |

5.4 Verify certificate:

|  |
| --- |
| aws iam list-server-certificates --query 'ServerCertificateMetadataList[?ServerCertificateName==`<CERTIFICATE-NAME>`]' |

## 6: Mitigation Using CloudFormation (IaC)

CloudFormation remediation is enforced by removing IAM server certificate resources from the stack.

YAML:

|  |
| --- |
| Remove expired AWS::IAM::ServerCertificate resource  Resources:  LegacyServerCertificate:  Type: AWS::IAM::ServerCertificate |

Recommended CloudFormation Workflow

* Wiz identifies expired certificates
* Security validates non usage
* Certificate resource is removed
* Change set is reviewed
* Stack update is executed

## 7: Mitigation Using Terraform (IaC)

Terraform should be used when IAM certificates are managed as Infrastructure as Code.

For expired IAM certificates:

* Terraform cannot “expire” or modify certificates
* Remediation is enforced by:

1. Removing expired certificate resources from Terraform
2. Applying Terraform to delete them from AWS

### 7.1 Remove Expired IAM Certificates Using Terraform

Ensure that expired IAM server certificates are no longer defined in Terraform code

Example (Before Remediation)

|  |
| --- |
| resource "aws\_iam\_server\_certificate" "example\_cert" {  name = "expired-cert"  certificate\_body = file("cert.pem")  private\_key = file("key.pem")  } |

Remediation Step

Remove the expired certificate resource:

|  |
| --- |
| # resource "aws\_iam\_server\_certificate" "example\_cert" {  # name = "expired-cert"  # certificate\_body = file("cert.pem")  # private\_key = file("key.pem")  # } |

6.3 Conditional Certificate Management (Best Practice)

Use variables to control certificate lifecycle:

|  |
| --- |
| variable "create\_certificate" {  type = bool  default = true  }  resource "aws\_iam\_server\_certificate" "this" {  count = var.create\_certificate ? 1 : 0  name = "app-cert"  certificate\_body = file("cert.pem")  private\_key = file("key.pem")  } |

For expired certificates:

Terraform

|  |
| --- |
| create\_certificate = false |

This ensures:

Expired certificates are automatically removed

Prevents accidental recreation

## 8: Document Exception

This guide will help you remove the expired IAM server certificate from your AWS account to resolve the security misconfiguration.

**In Wiz**: Add exception notes to the finding and set a periodic review reminder.

## 9. Preventive Control – AWS Config Managed Rule

**Regular Certificate Audits**: Implement automated checks for certificate expiration

**Certificate Rotation**: Replace certificates before they expire

**Monitoring**: Set up CloudWatch alarms for certificate expiration

**Documentation**: Maintain an inventory of all certificates and their usage

## 10. Validation and Success Criteria

Successful remediation is achieved when:

* Wiz findings for expired IAM certificates are reduced
* All expired certificates are removed or documented as exceptions
* IAM certificate inventory reflects only valid, active certificates