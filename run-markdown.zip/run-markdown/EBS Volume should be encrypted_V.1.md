![](data:image/png;base64...)

**Cloud Security Posture Management**

**Runbook – Remediation**

|  |  |  |
| --- | --- | --- |
| **Control Id** | **Control Name** | **Severity** |
| **EBS-003** | **EBS Volume should be encrypted** | **Medium** |

Version 1.0

**Table of Contents**

[1. Overview 1](#_Toc857815438)

[2. Objective 1](#_Toc1212899442)

[3. Triage ProcessPlease Refer to the below mentioned document: 2](#_Toc124769371)

[3.1 Identify Affected Volumes (Wiz) 2](#_Toc945333394)

[3.2 Categorize Findings 2](#_Toc246104113)

[4. Manual Mitigation – AWS Console 2](#_Toc1657408772)

[4.1 Encrypt Existing Unencrypted Volume (Snapshot Copy Method) 2](#_Toc1574981291)

[4.2: Encrypt Root Volume (AMI Rebuild Method) 3](#_Toc544864080)

[5. Mitigation – AWS CLI 3](#_Toc1356850749)

[6. Mitigation Using Terraform (IaC) 4](#_Toc1829433556)

[7. Mitigation Using Cloudformation (IaC) 5](#_Toc238764488)

[7.1 Preventive: Enforce Encryption for New EBS Volumes 5](#_Toc636497026)

[7.2 Preventive: Enable EBS Encryption by Default (Region-Level) 5](#_Toc567029671)

[Workflow: 5](#_Toc60549564)

[8: Document Exception 6](#_Toc1844868095)

[9. Detective / Preventive Controls 6](#_Toc219853728)

[9.1. AWS Config Rule (Recommended) 6](#_Toc824094002)

[9.2. Service Control Policy (SCP) – Strong Preventive Control : 6](#_Toc1683198132)

[10. Validation and Success Criteria 7](#_Toc648691658)

# 1. Overview

**Detection Tool**: Wiz Cloud Security Platform
**Hyperlink to the Rule**: [Cloud Configuration Rules | Wiz](https://app.wiz.io/policies/cloud-configuration-rules#%7E%28filters%7E%28search%7E%28contains%7E%27EBS*20Volume*20should*20be*20encrypted%29%29%7EcloudConfigurationRule%7E%277218d556-ee8c-4de9-a5be-ac55cbfc4801%29)
**AWS Config Managed Rule Name**: encrypted-volumes

This control identifies Amazon EBS volumes that are not encrypted at rest, as unencrypted storage increases the risk of unauthorized access and data exposure. All EBS volumes storing business data must be encrypted using AWS KMS (AWS‑managed or customer‑managed keys) in line with security standards. Compliance is monitored using the AWS Config managed rule **encrypted-volumes**, which detects unencrypted EBS volumes, while a Service Control Policy (SCP) serves as a strong preventive control by blocking the creation of unencrypted volumes across AWS accounts.

# 2. Objective

This runbook defines the standardized process to identify and remediate unencrypted Amazon EBS volumes, and to implement preventive controls to ensure all newly created EBS volumes are encrypted by default, reducing risk and improving audit readiness. This runbook aims to enforce encryption at rest for all Amazon EBS volumes by providing clear guidance to detect unencrypted resources, prevent non‑compliant volume creation, and remediate findings using AWS native controls, thereby reducing the risk of data exposure and ensuring continuous compliance with security standards.

# 3. Triage Process Please Refer to the below mentioned document:

[Master+Template+-+Remediation+SOP.docx](https://cargillonline.sharepoint.com/%3Aw%3A/r/sites/GIS-ADC-CloudSecurityTeam-TeamDiscussions-Private/_layouts/15/Doc.aspx?sourcedoc=%7B78D12AE6-08C4-4A84-AB4A-348A3A0F0F82%7D&file=Master%2BTemplate%2B-%2BRemediation%2BSOP.docx&action=default&mobileredirect=true)

## 3.1 Identify Affected Volumes (Wiz)

Navigate to Wiz → Cloud Configuration Findings and filter by the rule “EBS Volume should be encrypted”. Export the list of affected resources.

Collect the following details: Volume ID, AWS account ID, region, availability zone, attachment status (attached/detached), instance ID (if attached), volume type, size, tags (owner/business/app), and whether the volume is a root volume or data volume.

## 3.2 Categorize Findings

Category A – Safe to Remediate: Detached/non-production volumes, non-critical data volumes, or volumes with confirmed owners and maintenance window.

Category B – Requires Investigation: Attached production volumes, volumes with unclear ownership, shared service instances, or volumes used by stateful applications.

Category C – Business-Critical (Exceptions): Volumes that cannot be remediated immediately due to operational constraints, approved exception, or pending migration plan.

\*\*Note\*\*: Confirm workload impact, backup/snapshot readiness, instance dependency (root vs data volume), and change approval before remediation.

# 4. Manual Mitigation – AWS Console

4.1 Encrypt Existing Unencrypted Volume (Snapshot Copy Method)**:**

\*\*Important\*\*: AWS does not support encrypting an existing EBS volume in-place. Remediation requires creating an encrypted copy and swapping the volume.

**Step 1**: AWS Console → EC2 → Volumes → Select the unencrypted volume.

**Step 2**: Select Actions → Create snapshots. Wait for snapshot status = Completed.

**Step 3**: EC2 → Snapshots → Select the snapshot → Actions → Copy snapshot.

**Step 4**: Enable \*\*Encryption\*\* and select the required \*\*KMS key\*\* (aws/ebs or customer-managed key). Create the encrypted snapshot.

**Step 5**: Create a new encrypted volume from the encrypted snapshot (Actions → Create volume). Ensure the availability zone matches the target instance.

**Step 6**: If the volume is attached: stop the instance (recommended for root volumes); detach the unencrypted volume; attach the new encrypted volume with the same device name.

**Step 7**: Start the instance and validate OS boot, mount points, application functionality, and logs.

Post-action: Monitor workload for 7–14 days and retain the old, detached volume/snapshot per retention policy before deletion.

4.2: Encrypt Root Volume (AMI Rebuild Method)

Use this method if snapshot copy swap is operationally constrained or if you prefer AMI-based rebuild.

Step 1: Create an AMI from the instance (ensure encryption is enabled for snapshots/volumes where applicable).

Step 2: Copy the AMI/snapshots with encryption enabled (select KMS key).

Step 3: Launch a new instance from the encrypted AMI and perform cutover using change management.

# 5. Mitigation – AWS CLI

**Create Snapshot:**

|  |
| --- |
| *aws ec2 create-snapshot --volume-id <VOLUME\_ID> --description "Snapshot for EBS encryption remediation"* |

**Copy Snapshot with Encryption Enabled**:

|  |
| --- |
| *aws ec2 copy-snapshot --source-region <REGION> --source-snapshot-id <SNAPSHOT\_ID> --encrypted --kms-key-id <KMS\_KEY\_ID>* |

**Create Encrypted Volume from Encrypted Snapshot**:

*aws ec2 create-volume --snapshot-id <ENCRYPTED\_SNAPSHOT\_ID> --availability-zone <AZ> --volume-type <gp3|gp2|io2> --encrypted --kms-key-id <KMS\_KEY\_ID>*

**Detach and Attach (example):**

|  |
| --- |
| *aws ec2 detach-volume --volume-id <OLD\_VOLUME\_ID>*  *aws ec2 attach-volume --volume-id <NEW\_ENCRYPTED\_VOLUME\_ID> --instance-id <INSTANCE\_ID> --device <DEVICE\_NAME>* |

## 6. Mitigation Using Terraform (IaC)

Terraform should be used to ensure all new EBS resources are created encrypted and to prevent drift. Terraform cannot encrypt an existing volume in place; remediation requires a replace/swap workflow**.**

**6.1 Preventive: Enforce Encryption for New EBS Volumes.**

|  |
| --- |
| *resource "aws\_ebs\_volume" "this" {*  *availability\_zone = var.availability\_zone*  *size = var.size*  *type = var.volume\_type*  *encrypted = true*  *kms\_key\_id = var.kms\_key\_id # e.g., alias/aws/ebs or CMK ARN*  *tags = var.tags*  *}* |

**6.2 Preventive: Enable EBS Encryption by Default (Region-Level)**

|  |
| --- |
| *resource "aws\_ebs\_encryption\_by\_default" "this" {*  *enabled = true*  *}*  *# Optional: enforce default KMS key (recommended)*  *resource "aws\_ebs\_default\_kms\_key" "this" {*  *key\_arn = var.kms\_key\_arn*  *}* |

**6.3 Recommended Terraform Workflow**

1. Wiz identifies unencrypted EBS volumes, and the owner is confirmed.

2. Change request is raised with planned downtime (if applicable).

3. Terraform is updated to enforce encryptions for all new volumes (preventive) and to rebuild/replace resources where feasible.

4. terraform plan is reviewed and approved.

5. terraform apply enforces the preventive controls and approved rebuilds.

## 7. Mitigation Using Cloudformation (IaC)

CloudFormation enforces remediation by ensuring all new EBS volumes are created encrypted and enforcing region-level encryption defaults. Existing unencrypted volumes require a **snapshot-copy-and-replace workflow**.

## 7.1 Preventive: Enforce Encryption for New EBS Volumes

|  |
| --- |
| Resources:    EBSVolume:  Type: AWS::EC2::Volume  Properties:  AvailabilityZone: !Ref AvailabilityZone  Size: !Ref VolumeSize  VolumeType: !Ref VolumeType  Encrypted: true  KmsKeyId: !Ref KmsKeyId # alias/aws/ebs or CMK ARN  Tags:  - Key: Name  Value: EncryptedVolume  `` |

## 7.2 Preventive: Enable EBS Encryption by Default (Region-Level)

|  |
| --- |
| Resources:    EbsEncryptionByDefault:  Type: AWS::EC2::EBSVolume  Properties: {}  # Note: Native CloudFormation does not directly support enabling EBS encryption by default.  # This is typically configured via CLI/Automation or custom resource.  `` |

### **Workflow:**

1. Wiz identifies unencrypted EBS volumes
2. Security validates impact (replacement required)
3. CloudFormation enforces encryption for new resources
4. Region-level encryption default is enabled via automation
5. Existing volumes are remediated using snapshot-copy-and-replace workflow
6. Updated encrypted volume replaces the original volume

## **8: Document Exception**

Use when an unencrypted volume must remain temporarily due to business constraints.

Required documentation includes:

- Business justification

- Approver name and approval date

- Exception expiration date

- Compensating controls (restricted IAM access, instance hardening, monitoring, backup controls)

In Wiz: Add exception notes to the finding and set a periodic review reminder.

# 9. Detective / Preventive Controls

## 9.1. AWS Config Rule (Recommended)

* Rule Name: **encrypted volumes**
* Type: AWS Managed Rule
* Ensures all new EBS volumes are encrypted

**Steps:**

1. Navigate to **AWS Config**
2. Add rule → AWS managed rules
3. Select **encrypted volumes**
4. Enable the rule

**Result:**

* Continuous detection inside AWS
* Independent evidence for audits

9.2. Service Control Policy (SCP) – Strong Preventive Control :

Blocks creation of unencrypted EBS volumes across the organization.

|  |
| --- |
| *{*  *"Version": "2012-10-17",*  *"Statement": [*  *{*  *"Sid": "DenyUnencryptedEBS",*  *"Effect": "Deny",*  *"Action": "ec2:CreateVolume",*  *"Resource": "\*",*  *"Condition": {*  *"Bool": {*  *"ec2:Encrypted": "false"*  *}*  *}*  *}*  *]*  *}* |

# 10. Validation and Success Criteria

Successful remediation is indicated by:

- Wiz finding status reduced/closed for the affected volume(s).

- EC2 console shows Volume Encryption = Yes (KMS).

- AWS Config rule `encrypted-volumes` shows Compliant for the resource(s).

- No workload disruption after cutover and monitoring window.