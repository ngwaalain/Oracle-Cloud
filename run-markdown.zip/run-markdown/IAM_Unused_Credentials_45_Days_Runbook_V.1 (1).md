![](data:image/png;base64...)

**Cloud Security Posture Management**

**Runbook – Remediation**

|  |  |  |
| --- | --- | --- |
| **Control Id** | **Control Name** | **Severity** |
| **IAM-046** | **IAM User credentials unused for 45 days or more should be disabled** | **Medium** |

Version 1.0

# Table of Contents

[Table of Contents 1](#_Toc377662336)

[1. Overview 1](#_Toc1515698215)

[2. Objective 2](#_Toc684985931)

[4. Manual Mitigation – AWS Console 3](#_Toc1559276467)

[4.1 Deactivate the user: 3](#_Toc22834774)

[4.2: Disable Console Access 3](#_Toc383047642)

[4.3. Delete IAM User (Only If Fully Approved) 3](#_Toc1909690564)

[5. Mitigation – AWS CLI 4](#_Toc831344972)

[6. Mitigation Using Terraform (IaC) 4](#_Toc745240248)

[6.1 Disable Console Access Using Terraform 4](#_Toc1068734670)

[6.2 Remove Access Keys Using Terraform 4](#_Toc1934610793)

[6.3 Recommended Terraform Workflow 5](#_Toc1004880440)

[6.4 Guardrails for Terraform 5](#_Toc1239594610)

[8. Preventive Control – AWS Config Managed Rule 5](#_Toc2021398017)

[9. Validation and Success Criteria 6](#_Toc1761541787)

# 1. Overview

**Detection Tool**: Wiz Cloud Security Platform
**Hyperlink to the Rule**: [Cloud Configuration Rules | Wiz](https://app.wiz.io/policies/cloud-configuration-rules#%7E%28filters%7E%28search%7E%28contains%7E%27IAM*20User*20credentials*20unused*20for*2045*20days*20or*20more*20should*20be*20disabled%29%29%7EcloudConfigurationRule%7E%278706bdb7-8560-42eb-931b-552b2721963e%29)
**AWS Config Managed Rule Name**: iam-user-unused-credentials-check

This control is designed to proactively identify IAM users whose credentials—either console passwords or access keys—have remained unused for a period exceeding 45 days. Such dormant credentials often represent unmanaged or forgotten identities, significantly increasing the risk of unauthorized access if compromised.

By continuously monitoring and flagging these inactive credentials, the control enables timely remediation actions such as disabling or removing unused access, thereby reducing the organization’s attack surface.

From a **preventive security standpoint**, this control enforces strong identity and access hygiene by ensuring that only actively used and validated credentials remain enabled. This directly supports the principle of least privilege, minimizes the possibility of credential misuse, and helps prevent potential security incidents before they occur.

To operationalize this control, enable the AWS Config managed rule **iam-user-unused-credentials-check**, which provides continuous compliance monitoring and automated detection of unused IAM credentials across the environment.

# 2. Objective

The objective of this runbook is to establish a standardized and auditable process for identifying, reviewing, and remediating IAM user credentials that have been inactive for 45 days or more. This process aims to minimize the risk of unauthorized access by eliminating unused or stale credentials, enforce strong identity and access management practices, and strengthen the organization’s overall security posture through **preventive controls** and continuous monitoring.

**3. Triage Process**

**Please Refer to the below mentioned document:**

[Master+Template+-+Remediation+SOP.docx](https://cargillonline.sharepoint.com/%3Aw%3A/r/sites/GIS-ADC-CloudSecurityTeam-TeamDiscussions-Private/_layouts/15/Doc.aspx?sourcedoc=%7B78D12AE6-08C4-4A84-AB4A-348A3A0F0F82%7D&file=Master%2BTemplate%2B-%2BRemediation%2BSOP.docx&action=default&mobileredirect=true)

**3.1 Identify Affected Users (Wiz)**

Navigate to Wiz → Cloud Configuration Findings and filter by the rule “IAM User credentials unused for 45 days or more should be disabled”. Export the list of affected IAM users.

Collect the following details: IAM username, AWS account ID, console last-used date, access key last-used dates, user creation date, and ownership tags.

**3.2 Categorize Users**

Category A – Safe to Disable/Delete: Test, demo, former employee, or temporary accounts.

Category B – Requires Investigation: Service accounts, shared users, break-glass users, or unclear ownership.

Category C – Business-Critical (Exceptions): Audit-mandated or approved exception users.

**Note** : *Confirm the user's purpose, owner, type (human or service), attached permissions, and MFA status before acting*.

# 4. Manual Mitigation – AWS Console

4.1 Deactivate the user:

This action is safe, reversible, and low risk

Step 1: Navigate to AWS Console → IAM → Users and select the affected IAM user reported by Wiz.

Step 2: Review Security Credentials to confirm console password and access key last-used dates exceed 45 days.

Step 3: Disable unused access keys by selecting the key and choosing Deactivate.

Post-action:
- Monitor for 7–14 days
- Document any service impact
- Proceed to further actions if no issues are observed

Result:

Access key status changes to Inactive

Key can no longer be used

User object remains intact

### 4.2: Disable Console Access

Use this option when the user requires only programmatic access or console usage is unnecessary.
If Wiz shows console password unused for ≥45 days:Under Security credentials ->Locate Console sign in->Click Disable console access->Confirm the action

**Result**:

Console login is removed
Programmatic access (if any) is unaffected

## 4.3. Delete IAM User (Only If Fully Approved)

**Delete the user only when:**

Credentials were disabled
No usage or impact observed

Business owner approval obtained

**High-level console steps:**

1. Remove user from groups

2. Detach managed policies

3. Delete inline policies

4. Delete access keys

5. Remove MFA devices (if any)

6. Delete login profile

7. Delete the user

# 5. Mitigation – AWS CLI

**Disable access keys:**

|  |
| --- |
| ***aws iam update-access-key --user-name <USERNAME> --access-key-id <ACCESS\_KEY\_ID> --status Inactive*** |

**Disable console access:**

|  |
| --- |
| ***aws iam delete-login-profile --user-name <USERNAME>*** |

# 6. Mitigation Using Terraform (IaC)

Terraform should be used when IAM users and credentials are managed as Infrastructure as Code. Terraform cannot directly “disable” an access key; instead, it enforces remediation by removing or preventing creation of unused credentials.

## 6.1 Disable Console Access Using Terraform

If the IAM user login profile is managed in Terraform, remove or conditionally disable it.

|  |
| --- |
| ***resource "aws\_iam\_user\_login\_profile" "this" {***  ***count = var.enable\_console\_access ? 1 : 0***  ***user = aws\_iam\_user.this.name*** ***}*** |

## 6.2 Remove Access Keys Using Terraform

Terraform enforces remediation by deleting unused access keys. Set the access key resource count to zero once identified as unused.

|  |
| --- |
| ***resource "aws\_iam\_access\_key" "this" {***  ***count = var.create\_access\_key ? 1 : 0***  ***user = aws\_iam\_user.this.name*** ***}*** |

## 6.3 Recommended Terraform Workflow

1. Wiz identifies unused credentials.
2. The security team validates the impact.
3. Terraform variables are updated to disable console access or remove access keys.
4. The terraform plan is reviewed and approved.
5. terraform apply enforces the change.

## 6.4 Guardrails for Terraform

Use lifecycle rules and CI/CD checks to prevent recreation of access keys without approval. Prefer IAM roles over IAM users for applications.

7: Document Exception

Use when the IAM user must remain active for valid business reasons.

Required documentation includes:
- Business justification
- Approver name and approval date
- Exception expiration date
- Compensating controls (MFA, restricted permissions)

In Wiz: Add exception notes to the finding and set a periodic review reminder.

# 8. Preventive Control – AWS Config Managed Rule

Enable AWS Config managed rule iam-user-unused-credentials-check to continuously detect unused IAM credentials.

Steps:
1. Navigate to AWS Config
2. Add Rule → AWS Managed Rule
3. Select iam-user-unused-credentials-check
4. Set MaximumCredentialUsageAge to 45 days
5. Save and enable the rule

**Result:**

Continuous detection inside AWS

Independent evidence for audits

# 9. Validation and Success Criteria

Reduction in Wiz failed checks, no service disruption, and continuous compliance visibility via AWS Config.