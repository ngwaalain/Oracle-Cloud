![](data:image/png;base64...)

**Cloud Security Posture Management**

**Runbook – Remediation**

|  |  |  |
| --- | --- | --- |
| **Control Id** | **Control Name** | **Severity** |
| IAM-023 | [*Root account should be configured to use a hardware MFA device and only a hardware MFA device*](https://app.wiz.io/policies/cloud-configuration-rules#%7E%28cloudConfigurationRule%7E%272fdc0f9a-c493-4cbf-9354-d63212b1e7b5%29) | **Medium** |

Version 1.0

Table of Contents

[1. Overview 2](#_Toc2125298655)

[Description: 2](#_Toc1070735725)

[2. Objective 3](#_Toc57814966)

[3. Triage Process 3](#_Toc723238397)

[3.1 Identify Affected Accounts (Wiz) 3](#_Toc2066720774)

[3.2 Categorize Findings 3](#_Toc1270320138)

[4. Manual Mitigation – AWS Console 4](#_Toc2044950218)

[4.1 Verify Root MFA 4](#_Toc1966380747)

[4.2 Configure Hardware MFA 4](#_Toc1777362576)

[Verify Root MFA Status: 4](#_Toc1412065199)

[6. Mitigation Using Terraform (IaC) 4](#_Toc104980693)

[7. Document Exception 4](#_Toc1828447461)

[8. Preventive Control 5](#_Toc314930882)

[9. Validation and Success Criteria 5](#_Toc614052310)

# 1. Overview

**Detection Tool:** Wiz Cloud Security Platform

**Hyperlink to the Rule:** [Cloud Configuration Rules – Wiz](https://app.wiz.io/policies/cloud-configuration-rules#%7E%28cloudConfigurationRule%7E%273ff7127e-0a07-4082-80df-02db44058080%29)

**Rule Type:** Wiz Custom Configuration Rule

Description:
This control evaluates whether the **AWS Root account is protected exclusively with a hardware-based Multi‑Factor Authentication (MFA) device**, ensuring the highest level of security for the most privileged identity in the AWS account.

The AWS Root account has unrestricted access to all services and resources, including billing, account settings, and security configurations. Due to its elevated privileges, compromise of the root account can result in complete loss of control over the AWS environment.

The rule fails when:

* The Root account does not have MFA enabled, or
* The Root account is configured with a virtual (software-based) MFA device instead of a hardware MFA device, or
* Multiple MFA methods are allowed for the Root account instead of enforcing hardware MFA exclusively

Hardware MFA devices provide stronger protection compared to virtual MFA by being resistant to malware, phishing attacks, device compromise, and credential theft. Enforcing the use of **only a hardware MFA device** ensures that root authentication relies on a physical possession factor that cannot be easily replicated or intercepted.

This control helps ensure that:

* The AWS Root account is protected against credential compromise and unauthorized access
* Root-level actions require deliberate, physical user presence
* The organization adheres to AWS and industry best practices for privileged account security
* The risk of catastrophic security incidents arising from root account misuse is significantly reduced

# 2. Objective

Ensure the AWS Root account is protected with Multi-Factor Authentication (MFA) enabled at all times and that only a Hardware MFA device is used for authentication. The Root account must not be configured with any Virtual MFA devices, as virtual MFA introduces a higher risk of compromise.

Enforcing Hardware MFA exclusively for the Root account significantly strengthens security by requiring physical possession of the MFA device, thereby minimizing the attack surface. This control helps prevent unauthorized access, credential theft, and misuse of the most privileged account within the AWS environment, ensuring stronger protection against both external and internal threats.

## 3. Triage Process

Please Refer to the below mentioned document:
[Master+Template+-+Remediation+SOP.docx](https://cargillonline.sharepoint.com/%3Aw%3A/r/sites/GIS-ADC-CloudSecurityTeam-TeamDiscussions-Private/_layouts/15/Doc.aspx?sourcedoc=%7B78D12AE6-08C4-4A84-AB4A-348A3A0F0F82%7D&file=Master%2BTemplate%2B-%2BRemediation%2BSOP.docx&action=default&mobileredirect=true)

### 3.1 Identify Affected Accounts (Wiz)

* Navigate to Wiz → Cloud Configuration Findings
* Filter by rule: “Root account should be configured to use a hardware MFA device only”
* Review:
  MFA status (userCredentials.MfaActive)
  MFA type (Hardware vs Virtual)

### 3.2 Categorize Findings

Category A – Approved & Controlled

* Root account has **Hardware MFA enabled**
* No Virtual MFA configured

Category B – Requires Remediation

* No MFA enabled on root account
* Virtual MFA configured on root account

Category C – Not Required

* Root account not managed / no credentials detected

## 4. Manual Mitigation – AWS Console

### 4.1 Verify Root MFA

* Log in as Root user
* Navigate to IAM → Security credentials
* Review Multi-Factor Authentication (MFA) section

### 4.2 Configure Hardware MFA

* Remove Virtual MFA (if present)
* Assign a Hardware MFA device to the root account
* Complete MFA activation

**Result:**

* Root account protected using Hardware MFA only
* Wiz finding is resolved

5. Mitigation – AWS CLI
Note: Root account MFA cannot be configured via CLI. CLI can only be used for verification, not remediation.

Verify Root MFA Status:

|  |
| --- |
| *aws iam get-account-summary* |

Review the following fields:

* AccountMFAEnabled = 1 → MFA is enabled
* AccountMFAEnabled = 0 → MFA is not enabled
* If MFA is disabled or Virtual MFA is detected, remediation must be done via AWS Console.

Result:

* Confirms whether MFA is enabled on the root account
* Does not distinguish hardware vs virtual MFA

## 6. Mitigation Using Terraform (IaC)

* AWS does not support managing Root account MFA using Terraform
* Root account MFA (Hardware or Virtual) must be configured manually

Terraform cannot:

* Attach Hardware MFA to root
* Enforce Hardware-only MFA for root

## 7. Document Exception

This is a valid high‑level exception process and should be used only if Hardware MFA cannot be configured for the AWS Root account.

All exceptions must be formally reviewed, approved, and tracked until closure.

Required Details: TBD

* Business Justification:

Clearly document the reason for requesting the exception .

* AWS Account ID: Impacted AWS account where Hardware MFA cannot be enforced.
* Reason Hardware MFA Is Not Feasible:

Technical, operational, or dependency￼based limitation.

* Approver Name and Date: Authorized approver details.
* Review or Expiry Date: Defined date for revalidation or exception expiry.

Note: Exceptions must be temporary and reviewed periodically until Hardware MFA can be implemented.

## 8. Preventive Control

* Enforce Hardware MFA only for all root accounts
* Prohibit use of Virtual MFA for root
* Restrict and monitor root account usage
* Periodically review root credentials in Wiz

## 9. Validation and Success Criteria

The control is effective when:

* Root account has MFA enabled
* Only Hardware MFA is configured
* Wiz shows no open findings for this rule
* All exceptions are approved and documented