![](data:image/png;base64...)

**Cloud Security Posture Management**

**Runbook – Remediation**

|  |  |  |
| --- | --- | --- |
| **Control Id** | **Control Name** | **Severity** |
| IAM-007 | [*Access Keys Should Be Rotated Every 90 Days*](https://app.wiz.io/policies/cloud-configuration-rules#%7E%28cloudConfigurationRule%7E%27f3950a91-92c3-44ce-81d7-a14461e59846%29) | Medium |

Version 1.0

# Table of Content

[Table of Content 2](#_Toc1677031028)

[1. Overview 2](#_Toc1694853693)

[Description: 2](#_Toc1340681382)

[2. Objective 3](#_Toc2056757056)

[3. Triage Process 3](#_Toc2035664996)

[3.1 Identify Affected Users (Wiz) 3](#_Toc169600044)

[3.2 Categorize Findings 4](#_Toc671696186)

[4. Manual Mitigation – AWS Console 4](#_Toc424014402)

[4.1 Review Access Keys 4](#_Toc679982833)

[4.2 Rotate or Disable Access Keys 4](#_Toc1438629261)

[5. Mitigation – AWS CLI 4](#_Toc1685054227)

[6. Mitigation Using Terraform (IaC) 5](#_Toc1055164066)

[7. Mitigation Using CloudFormation (IaC) 5](#_Toc1050216905)

[CloudFormation + Manual / External Rotation (Most Common) 6](#_Toc1243570958)

[8. Document Exception 6](#_Toc1236856485)

[9. Preventive Control 7](#_Toc751698042)

[10. Validation and Success Criteria 7](#_Toc1991031099)

# 1. Overview

**Detection Tool**: Wiz Cloud Security Platform
**Hyperlink to the Rule**: [Cloud Configuration Rules | Wiz](https://app.wiz.io/policies/cloud-configuration-rules#%7E%28filters%7E%28search%7E%28contains%7E%27IAM*20User*20should*20not*20be*20inactive*20for*20more*20than*2090*20days%29%29%7EcloudConfigurationRule%7E%2784c88b3d-19cd-4140-86c7-8dd2f69f895e%29)
**Preventive/Detective Control**: AWS Access Keys credential reports.

Description:

This control evaluates whether AWS IAM user access keys are rotated on a regular basis in accordance with security best practices. IAM access keys that remain active for extended periods increase the risk of credential compromise, misuse, or unauthorized access—especially if the keys are exposed, shared, or insufficiently monitored.

The rule assesses the rotation age of all IAM user access keys by checking the values of **AccessKey1LastRotated** and **AccessKey2LastRotated**. The control fails when either active access key has not been rotated within the last **90 days**, indicating the presence of stale credentials.

Regular rotation of access keys helps reduce the attack surface, limits the potential impact of key compromise, and enforces stronger identity and access management hygiene. Failure of this rule highlights IAM users with long‑lived access keys that should be rotated or replaced to maintain compliance with organizational security standards and AWS recommended practices.

## 2. Objective

The objective of this control is to identify, assess, and remediate access keys that have not been rotated within the defined 90‑day threshold, ensuring that long‑lived or stale credentials do not introduce security risk. This control ensures that:

* Access keys used for programmatic access are rotated on a regular 90‑day cycle in line with AWS security best practices and organizational credential‑management standards
* Outdated, unused, or unnecessary access keys are promptly reviewed and either rotated, disabled, or deleted to reduce the risk of credential compromise
* Programmatic access is intentionally granted, actively maintained, and continuously validated, preventing unauthorized or unintended access through forgotten or exposed keys
* Credential usage aligns with the principle of least privilege, strong credential hygiene, and audit and compliance requirements, supporting traceability, accountability, and security monitoring

## 3. Triage Process

Please Refer to the below mentioned document:
[Master+Template+-+Remediation+SOP.docx](https://cargillonline.sharepoint.com/%3Aw%3A/r/sites/GIS-ADC-CloudSecurityTeam-TeamDiscussions-Private/_layouts/15/Doc.aspx?sourcedoc=%7B78D12AE6-08C4-4A84-AB4A-348A3A0F0F82%7D&file=Master%2BTemplate%2B-%2BRemediation%2BSOP.docx&action=default&mobileredirect=true)

### 3.1 Identify Affected Users (Wiz)

Navigate to Wiz → Cloud Configuration Findings

Filter by rule **“Access keys should be rotated every 90 days”**

Identify impacted:

* IAM username
* Access key ID
* Last rotated date
* Key status (Active / Inactive)

### 3.2 Categorize Findings

**Category A – Approved & Controlled**

* Key rotation delay approved
* Temporary or break glass usage documented

**Category B – Requires Remediation**

* Access keys older than 90 days
* Active keys with no rotation evidence

**Category C – Not Required**

* Inactive or unused keys
* Users with no programmatic access need

## 4. Manual Mitigation – AWS Console

### 4.1 Review Access Keys

* Navigate to AWS Console → IAM → Users
* Select the affected user → Security credentials
* Review Last rotated date of access keys

### 4.2 Rotate or Disable Access Keys

* Create a new access key
* Update applications with the new key
* Deactivate or delete the old access key

**Result**

* Access keys comply with 90-day rotation
* Wiz finding is resolved

## 5. Mitigation – AWS CLI

List access keys:

|  |
| --- |
| aws iam list-access-keys --user-name <USER\_NAME> |

Deactivate old key:

|  |
| --- |
| aws iam update-access-key --user-name <USER\_NAME> --access-key-id <KEY\_ID> --status Inactive |

## 6. Mitigation Using Terraform (IaC)

* Ensure IAM users do not rely on long-lived access keys
* Prefer IAM roles over static access keys
* Rotate and redeploy keys if managed via Terraform

# 90-day rotation trigger

|  |
| --- |
| resource "time\_rotating" "access\_key\_90d" {    rotation\_days = 90  }  # Access key that is force-recreated every 90 days  resource "aws\_iam\_access\_key" "service\_user\_key" {    user   = aws\_iam\_user.service\_user.name    status = "Active"  lifecycle {      replace\_triggered\_by = [time\_rotating.key\_90d.id]    }  } |

Result**:**

* Reduced exposure from long-lived credentials
* Wiz finding is resolved

7. Mitigation Using CloudFormation (IaC)

Eliminate Access Keys and Use IAM Roles

|  |
| --- |
| Resources:  ServiceRole:  Type: AWS::IAM::Role  Properties:  RoleName: service-role  AssumeRolePolicyDocument:  Version: "2012-10-17"  Statement:  - Effect: Allow  Principal:  Service: ec2.amazonaws.com  Action: sts:AssumeRole |

CloudFormation + Manual / External Rotation (Most Common)

Create IAM users and access keys with CloudFormation, but **rotate externally** using:

* AWS Lambda + EventBridge (90‑day schedule)
* AWS Secrets Manager rotation
* CI/CD pipeline rerunning the stack

|  |
| --- |
| Resources:  ServiceUser:  Type: AWS::IAM::User  Properties:  UserName: service-user    ServiceUserAccessKey:  Type: AWS::IAM::AccessKey  Properties:  UserName: !Ref ServiceUser  Status: Active |

## 8. Document Exception

All exceptions must be formally reviewed, approved, and time‑bound. Until finalized, the exception status should be marked as TBD.

Required Details:

* Business justification: Reason access key rotation cannot be performed (TBD)
* IAM user and AWS account ID: Impacted user and account details (TBD)
* Approver name and date: Management or security approval (TBD)
* Expiry or review date: Exception end date or next review cycle (TBD)
* Compensating controls: Enhanced monitoring, logging, MFA, or other safeguards (TBD)

Note: Exceptions must be periodically reviewed and revoked once the underlying constraint is resolved.

## 9. Preventive Control

* Enforce 90-day access key rotation policy
* Prefer IAM roles over access keys
* Periodically review access keys using Wiz
* Disable unused or inactive keys

## 10. Validation and Success Criteria

The control is effective when:

* No IAM access keys exceed 90 days since last rotation
* All exceptions are approved and documented
* Wiz shows no open findings for this rule