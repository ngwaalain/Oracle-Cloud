![A green leaf on a black background

AI-generated content may be incorrect.](data:image/png;base64...)

**Cloud Security Posture Management**

**Runbook – Remediation**

|  |  |  |
| --- | --- | --- |
| **Control Id** | **Control Name** | **Severity** |
| **IAM-005** | **IAM User with console access should have MFA enabled** | **High** |

Version 1.0

Table of Contents

[1.Overview 3](#_Toc228783815)

[2. Objective 3](#_Toc228783816)

[3. Triage Process 4](#_Toc228783817)

[3.1 Identify Affected Users (Wiz) 4](#_Toc228783818)

[4. Manual Mitigation – AWS Console 4](#_Toc228783819)

[4.1 Enable MFA for IAM User (Preferred) 4](#_Toc228783820)

[4.2 Remove Console Access (If MFA Cannot Be Enabled) 5](#_Toc228783821)

[5. Mitigation – AWS CLI 5](#_Toc228783822)

[6. Mitigation Using CloudFormation (IaC): 5](#_Toc228783823)

[7. Document Exception 6](#_Toc228783824)

[8. Preventive Control – AWS Config Managed Rule 6](#_Toc228783825)

[9. Validation and Success Criteria 7](#_Toc228783826)

## 1.Overview

**Detection Too**l: Wiz Cloud Security Platform

**Hyperlink to the Rule**: [Cloud Configuration Findings | Wiz](https://app.wiz.io/findings/configuration-findings/cloud#%7E%28filters%7E%28status%7E%28equals%7E%28%7E%27OPEN%29%29%7Erule%7E%28equals%7E%28%7E%27fbb6c52f-d8e1-45c6-be9c-71f0ca525e24%29%29%29%29)

**Description**

This control identifies AWS IAM users who have AWS Management Console access enabled but do not have Multi Factor Authentication (MFA) configured on their accounts.

IAM users with console access are high value targets, as console credentials provide interactive access to AWS resources. The absence of MFA significantly increases the risk of unauthorized access in the event of password compromise through phishing, credential reuse, brute force attacks, or malware.

This metric enforces strong authentication controls for IAM users by ensuring that MFA is enabled wherever console access exists. Enabling MFA adds an additional layer of security beyond static passwords and is a core AWS IAM security best practice.

This control is detective in nature, as AWS Config does not enforce MFA for IAM users by default. Wiz continuously evaluates IAM credential reports to identify console enabled users without MFA and generates findings for remediation.

## 2. Objective

This runbook defines the standardized process to identify, remediate, and prevent IAM users with AWS console access from operating without MFA enabled. The objective is to reduce the risk of account takeover and align with AWS and organizational security standards.

Console access without MFA:

* Increases the likelihood of account takeover
* Violates AWS IAM security best practices
* Represents a critical authentication weakness in cloud environments

This runbook provides guidance to:

* Validate MFA findings
* Identify affected IAM users
* Enable MFA or remove unnecessary console access
* Manage approved exceptions with compensating controls

The goal is to ensure 100% MFA coverage for all IAM users with console access, thereby reducing the risk of unauthorized access and ensuring compliance with organizational security standards.

## 3. Triage Process

Please Refer to the below mentioned document:

[Master+Template+-+Remediation+SOP.docx](https://cargillonline.sharepoint.com/%3Aw%3A/r/sites/GIS-ADC-CloudSecurityTeam-TeamDiscussions-Private/_layouts/15/Doc.aspx?sourcedoc=%7B78D12AE6-08C4-4A84-AB4A-348A3A0F0F82%7D&file=Master%2BTemplate%2B-%2BRemediation%2BSOP.docx&action=default&mobileredirect=true)

### 3.1 Identify Affected Users (Wiz)

1. Navigate to Wiz → Cloud Configuration Findings.
2. Filter by the rule “IAM User with console access should have MFA enabled”.
3. Export the list of affected IAM users.
4. Collect the following details:

* IAM username
* AWS account ID
* Console access status
* MFA status (Enabled/Disabled)
* User creation date
* Ownership tags (if available)

## 4. Manual Mitigation – AWS Console

### 4.1 Enable MFA for IAM User (Preferred)

This action is safe, recommended, and low risk.

Steps:

1. Sign in to AWS Console → IAM → Users.
2. Select the affected IAM user.
3. Navigate to Security credentials.
4. Under Assigned MFA device, choose Add MFA device.
5. Select MFA type:

* Virtual MFA device (recommended)
* Hardware MFA device (if required)

1. Complete device configuration and activate MFA.

Result:

* MFA status changes to Enabled
* Console login now requires MFA

### 4.2 Remove Console Access (If MFA Cannot Be Enabled)

Use this option if the user does not require console access.

Steps:

1. IAM → Users → Select user.
2. Go to Security credentials.
3. Under Console sign-in, choose Disable console access.

Result:

* Console access removed
* Programmatic access (if any) remains unaffected

## 5. Mitigation – AWS CLI

Check MFA devices:

|  |
| --- |
| aws iam list-mfa-devices --user-name <USERNAME> |

Enable MFA: MFA activation must be completed interactively and cannot be fully automated via CLI.

Remove console access (alternative):

|  |
| --- |
| aws iam delete-login-profile --user-name <USERNAME> |

## 6. Mitigation Using CloudFormation (IaC):

CloudFormation remediation focuses on controlling console access, as MFA devices cannot be directly managed via templates.

YAML:

|  |
| --- |
| Parameters:  EnableConsoleAccess:  Type: String  AllowedValues:  - true  - false  Default: false  Conditions:  CreateConsoleAccess: !Equals [ !Ref EnableConsoleAccess, true ]  Resources:  IAMUserLoginProfile:  Type: AWS::IAM::LoginProfile  Condition: CreateConsoleAccess  Properties:  UserName: !Ref IAMUser  PasswordResetRequired: true |

Recommended CloudFormation Workflow

* Wiz identifies non MFA console users
* Security validates business usability
* Console access is conditionally restricted
* Stack update is reviewed and applied

## 7. Document Exception

Use only when MFA cannot be enabled due to valid business reasons.

Required documentation:

* Business justification
* Approver name and approval date
* Exception expiration date
* Compensating controls (restricted permissions, IP allowlists)

In Wiz:

* Add exception notes to the finding
* Schedule periodic exception review

## 8. Preventive Control – AWS Config Managed Rule

Enable AWS Config managed rule iam-user-mfa-enabled.

Steps:

1. Navigate to AWS Config
2. Add Rule → AWS Managed Rule
3. Select iam-user-mfa-enabled
4. Save and enable the rule

Result:

* Continuous detection of non-MFA console users
* Audit-ready compliance evidence

## 9. Validation and Success Criteria

* No IAM users with console access lack MFA
* Wiz findings reduced to zero for this rule
* No business disruption reported
* Continuous compliance visibility via AWS Config