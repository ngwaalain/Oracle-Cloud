Version 1.0

![](data:image/png;base64...)

**Cloud Security Posture Management**

**Runbook – Remediation**

|  |  |  |
| --- | --- | --- |
| **Control Id** | **Control Name** | **Severity** |
| **IAM-047** | **IAM User should not be inactive for more than 90 days .** | **Medium** |

**Table of Contents**

[1. Overview 2](#_Toc227227064)

[2. Description 2](#_Toc227227065)

[3. Objective 3](#_Toc227227066)

[4. Triage Process 3](#_Toc227227067)

[4.1. Identify Affected Users (Wiz) 3](#_Toc227227068)

[4.2. Categorize Users 3](#_Toc227227069)

[5. Manual Mitigation – AWS Console 4](#_Toc227227070)

[5.1. Deactivate the user: 4](#_Toc227227071)

[5.2. Disable Console Access 4](#_Toc227227072)

[5.3. Delete IAM User (Only If Fully Approved) 4](#_Toc227227073)

[6. Mitigation – AWS CLI 5](#_Toc227227074)

[7. Mitigation Using Terraform (IaC) 5](#_Toc227227075)

[7.1. Disable Console Access Using Terraform 5](#_Toc227227076)

[7.2. Remove Access Keys Using Terraform: 5](#_Toc227227077)

[7.3. Recommended Terraform Workflow 5](#_Toc227227078)

[8. Mitigation Using CloudFormation (IaC) 6](#_Toc227227079)

[8.1. Disable Console Access Using CloudFormation 6](#_Toc227227080)

[8.2. Remove Access Keys Using CloudFormation 6](#_Toc227227081)

[8.3. Recommended CloudFormation Workflow 7](#_Toc227227082)

[9. Document Exception 7](#_Toc227227083)

[10. Detective Control 7](#_Toc227227084)

[11. Validation and Success Criteria 8](#_Toc227227085)

# Overview

**Detection Tool:** Wiz Cloud Security Platform
**Hyperlink to the Rule:** [Cloud Configuration Rules | Wiz](https://app.wiz.io/policies/cloud-configuration-rules#%7E%28filters%7E%28search%7E%28contains%7E%27IAM*20User*20should*20not*20be*20inactive*20for*20more*20than*2090*20days%29%29%7EcloudConfigurationRule%7E%2784c88b3d-19cd-4140-86c7-8dd2f69f895e%29)
**Detective Control**: AWS IAM credential reports.

# Description This control identifies AWS IAM users inactive for more than 90 days based on last console and access‑key usage. Inactive users often represent orphaned identities whose credentials remain valid, increasing the risk of unauthorized access and non‑compliance.

The control supports identity hygiene by enabling periodic review and remediation of unused IAM users. It is detective in nature, leveraging AWS IAM credential reports and Wiz analysis, as no AWS Config managed rule exists for enforcing IAM inactivity thresholds.

# Objective

The objective of this runbook is to define a standardized process to **identify, review, and remediate AWS IAM users that have been inactive for more than 90 days**, as detected by the Wiz Cloud Security Platform. Prolonged inactivity of IAM users increases the risk of unauthorized access, credential misuse, and non-compliance with identity and access management in best practices.

This document provides **clear operational guidance** for security and cloud operations teams to:

* Validate inactivity findings,
* Assess business ownership and risk,
* Safely disable or remove unused IAM credentials and users,
* Handle approved exceptions with appropriate compensating controls.

The goal is to ensure that all inactive IAM users are either **remediated, formally approved as exceptions, or decommissioned**, thereby reducing the attack surface and maintaining a strong security posture across AWS accounts.

# Triage Process

**Please Refer to the below mentioned document:**

[Master+Template+-+Remediation+SOP.docx](https://cargillonline.sharepoint.com/%3Aw%3A/r/sites/GIS-ADC-CloudSecurityTeam-TeamDiscussions-Private/_layouts/15/Doc.aspx?sourcedoc=%7B78D12AE6-08C4-4A84-AB4A-348A3A0F0F82%7D&file=Master%2BTemplate%2B-%2BRemediation%2BSOP.docx&action=default&mobileredirect=true)

## Identify Affected Users (Wiz)

Navigate to Wiz → Cloud Configuration Findings and filter by the rule “IAM User should not be inactive for more than 90 days”. Export the list of affected IAM users.

Collect the following details: IAM username, AWS account ID, last activity date, user creation date, and ownership tags.

## Categorize Users

Category A – Safe to Disable/Delete: Test, demo, former employee, or temporary accounts.

Category B – Requires Investigation: Service accounts, shared users, break-glass users, or unclear ownership.

Category C – Business-Critical (Exceptions): Audit-mandated or approved exception users.

**Note** : *Confirm the user's purpose, owner, type (human or service), attached permissions, and MFA status before acting*.

# Manual Mitigation – AWS Console

## Deactivate the user:

This action is safe, reversible, and low risk

Step 1: Navigate to AWS Console → IAM → Users and select the affected IAM user reported by Wiz.

Step 2: Review Security Credentials to confirm console password and access key last-used dates exceed 90 days.

Step 3: Disable console access and access keys if the user is no longer required.

Post-action:
- Monitor for 7–14 days
- Document any service impact
- Proceed to further actions if no issues are observed

**Result**:

* Access key status changes to **Inactive**
* Key can no longer be used
* User object remains intact

## Disable Console Access

**Use this option when the user requires only programmatic access or console usage is unnecessary.**

If Wiz shows console password unused for ≥90 days:

Under Security credentials ->Locate Console sign in->Click Disable console access->Confirm the action

**Result**:

Console login is removed

Programmatic access (if any) is unaffected

## Delete IAM User (Only If Fully Approved)

***Delete the user only when:***

* ***Credentials were disabled***
* ***No usage or impact observed***
* ***Business owner approval obtained***

**High-level console steps:**

1. Remove user from groups

2. Detach managed policies

3. Delete inline policies

4. Delete access keys

5. Remove MFA devices (if any)

6. Delete login profile

7. Delete the user

**Note**:
*If you do not want to delete the user completely, use can instead remove the user's ability to interact with AWS by deleting the user's password and access keys. Use the AWS CLI command delete-login-profile to remove the password, and delete-access-key to delete the access keys*

# Mitigation – AWS CLI

**Disable access key:**

|  |
| --- |
| *aws iam update-access-key --user-name <USERNAME> --access-key-id <ACCESS\_KEY\_ID> --status Inactive* |

**Disable console access:**

|  |
| --- |
| *aws iam delete-login-profile --user-name <USERNAME>* |

# Mitigation Using Terraform (IaC)

Terraform should be used when IAM users and credentials are managed as Infrastructure as Code. Terraform cannot directly “disable” an access key; instead, it enforces remediation by removing or preventing creation of unused credentials.

## Disable Console Access Using Terraform

If the IAM user login profile is managed in Terraform, remove or conditionally disable it.

|  |
| --- |
| *resource "aws\_iam\_user\_login\_profile" "this" {*  *count = var.enable\_console\_access ? 1 : 0*  *user = aws\_iam\_user.this.name* *}* |

## Remove Access Keys Using Terraform:

Terraform enforces remediation by deleting unused access keys. Set the access key resource count to zero once identified as unused.

|  |
| --- |
| *resource "aws\_iam\_access\_key" "this" {*  *count = var.create\_access\_key ? 1 : 0*  *user = aws\_iam\_user.this.name* *}* |

## Recommended Terraform Workflow

1. Wiz identifies unused credentials.
2. The security team validates the impact.
3. Terraform variables are updated to disable console access or remove access keys.
4. The terraform plan is reviewed and approved.
5. terraform apply enforces the change.

# Mitigation Using CloudFormation (IaC)

CloudFormation should be used when IAM users and credentials are managed as Infrastructure as Code.
 CloudFormation cannot “disable” an access key in place; remediation is enforced by removing IAM resources (login profiles or access keys) from the stack or conditionally preventing their creation.

## Disable Console Access Using CloudFormation

If the IAM user login profile is managed in CloudFormation, console access can be disabled by removing the AWS::IAM::LoginProfile resource or by conditionally controlling its creation using Conditions.

**Example: Conditional Console Access**

|  |
| --- |
| YAML  Parameters:  EnableConsoleAccess:  Type: String  AllowedValues:  - true  - false  Default: false  Conditions:  CreateConsoleAccess: !Equals [ !Ref EnableConsoleAccess, true ]  Resources:  IAMUser:  Type: AWS::IAM::User  Properties:  UserName: example-user  IAMUserLoginProfile:  Type: AWS::IAM::LoginProfile  Condition: CreateConsoleAccess  Properties:  UserName: !Ref IAMUser  PasswordResetRequired: true |

## Remove Access Keys Using CloudFormation

CloudFormation enforces remediation by **deleting unused access keys** from the stack.
 To remediate, the AWS::IAM::AccessKey resource must be **removed or conditionally excluded**.

**Example: Conditional Access Key Creation**

|  |
| --- |
| YAML  Parameters:  CreateAccessKey:  Type: String  AllowedValues:  - true  - false  Default: false  Conditions:  CreateAccessKeyCondition: !Equals [ !Ref CreateAccessKey, true ]  Resources:  IAMUser:  Type: AWS::IAM::User  Properties:  UserName: example-user  IAMUserAccessKey:  Type: AWS::IAM::AccessKey  Condition: CreateAccessKeyCondition  Properties:  UserName: !Ref IAMUser  Status: Active |

## Recommended CloudFormation Workflow

1. **Wiz identifies unused IAM credentials** (console access or access keys).
2. **Security team validates business and operational impact**.
3. **CloudFormation parameters or templates are updated**:
   1. Disable console access condition
   2. Remove or prevent access key creation
4. **Change set is created and reviewed**.
5. **Stack update is executed**, enforcing remediation.

# Document Exception

**"TB**D"
Use when the IAM user must remain active for valid business reasons.
Required documentation includes:

- Business justification
- Approver name and approval date
- Exception expiration date
- Compensating controls (MFA, restricted permissions)

# Detective Control

This control cannot be prevented using an AWS Config managed rule. AWS Config does not provide a managed rule to enforce IAM user inactivity thresholds.

IAM user inactivity is monitored using AWS IAM credential reports, which provide last used information for console passwords and access keys. Wiz Cloud Security Platform continuously analyzes this data to identify IAM users with no activity exceeding the defined threshold (90 days) and generates actionable findings for remediation.

IAM user inactivity is detected using AWS IAM credential reports, which provide last used information for console passwords and access keys. Wiz Cloud Security Platform continuously analyzes this data to identify IAM users that have been inactive for more than 90 days and generates findings for remediation.

**Steps for Detection**:
1. Log in to the AWS Management Console
2. Go to Services → IAM
3. Click Generate Report.
4. Wait until the status changes to Complete
5. Click Download report

# Validation and Success Criteria

Successful remediation is indicated by a reduction in Wiz findings and confirmation that inactive IAM users are either removed or formally approved as exceptions.