![](data:image/png;base64...)

**Cloud Security Posture Managment**

**Runbook – Remediation**

|  |  |  |
| --- | --- | --- |
| **Control Id** | **Control Name** | **Severity** |
| **EC2-004** | **EC2 instance is not using IMDSv2** | **High** |

Version 1.0

**Table of Content**

[Control Description 2](#_Toc1324033098)

[Phase 1 — Infrastructure as Code (Primary) 2](#_Toc1934391411)

[Phase 2 — Python Bulk Remediation (Secondary) 3](#_Toc1949015392)

[Python script: bulk\_imdsv2.py 4](#_Toc810877442)

[Run locally on macOS (AWS CLI already configured) 5](#_Toc50402121)

[Completion Check 6](#_Toc1099124680)

### **Control Description**

Wiz reports many EC2 instances not enforcing IMDSv2. The creation path has now been corrected in IaC, but older instances remain non-compliant.

### **Phase 1 — Infrastructure as Code (Primary)**

High-level steps:

1. Identify how affected instances are created (Terraform EC2 resource, Launch Template, ASG).
2. Locate the Terraform module/template responsible.
3. Enforce IMDSv2 defaults in IaC.
4. Deploy through standard pipelines.

****Terraform code to add****

****A)**** aws\_instance

resource "aws\_instance" "this" {

# ... existing config ...

metadata\_options {

http\_endpoint = "enabled"

http\_tokens = "required"

http\_put\_response\_hop\_limit = 2

}

}

****B)**** aws\_launch\_template

resource "aws\_launch\_template" "this" {

# ... existing config ...

metadata\_options {

http\_endpoint = "enabled"

http\_tokens = "required"

http\_put\_response\_hop\_limit = 2

}

}

****C)**** aws\_autoscaling\_group **(Launch Template)**

resource "aws\_autoscaling\_group" "this" {

# ... existing config ...

launch\_template {

id = aws\_launch\_template.this.id

version = "$Latest"

}

}

Notes:

* If legacy Launch Configurations exist, migrate to Launch Templates.
* IaC prevents recurrence; it does not automatically fix existing instances unless they are replaced.

### **Phase 2 — Python Bulk Remediation (Secondary)**

Use this to remediate ****existing instances at scale****.

****Input file (instances.txt)****
Create a file with one instance ID per line:

i-0123456789abcdef0

i-0abc1234def567890

#### **Python script: bulk\_imdsv2.py**

#!/usr/bin/env python3

import argparse

import sys

from typing import List

import boto3

from botocore.exceptions import ClientError

def read\_lines(path: str) -> List[str]:

items: List[str] = []

with open(path, "r", encoding="utf-8") as f:

for line in f:

v = line.strip()

if v and not v.startswith("#"):

items.append(v)

return items

def main() -> int:

p = argparse.ArgumentParser(description="Bulk enforce IMDSv2 on EC2 instances.")

p.add\_argument("--instances-file", required=True, help="Path to file containing EC2 instance IDs (one per line).")

p.add\_argument("--region", required=True, help="AWS region (e.g., us-east-1).")

p.add\_argument("--profile", default=None, help="AWS CLI profile name (optional).")

p.add\_argument("--dry-run", action="store\_true", help="Print actions without making changes.")

args = p.parse\_args()

instance\_ids = read\_lines(args.instances\_file)

if not instance\_ids:

print("No instance IDs found.", file=sys.stderr)

return 2

session = boto3.Session(profile\_name=args.profile, region\_name=args.region)

ec2 = session.client("ec2")

print(f"Region: {args.region}")

print(f"Profile: {args.profile or '(default)'}")

print(f"Instances: {len(instance\_ids)}")

print(f"Dry-run: {args.dry\_run}")

print("----")

failures = 0

for iid in instance\_ids:

try:

if args.dry\_run:

print(f"[DRY-RUN] Would update metadata options for {iid}")

continue

ec2.modify\_instance\_metadata\_options(

InstanceId=iid,

HttpTokens="required",

HttpEndpoint="enabled",

HttpPutResponseHopLimit=2,

)

print(f"[OK] Updated {iid}")

except ClientError as e:

failures += 1

print(f"[FAIL] {iid}: {e}", file=sys.stderr)

print("----")

print(f"Completed. Failures: {failures}")

return 1 if failures else 0

if \_\_name\_\_ == "\_\_main\_\_":

raise SystemExit(main())

#### **Run locally on macOS (AWS CLI already configured)**

python3 -m venv .venv

source .venv/bin/activate

pip install --upgrade pip boto3

# Dry-run first

python bulk\_imdsv2.py --instances-file instances.txt --region us-east-1 --profile myawsprofile --dry-run

# Execute

python bulk\_imdsv2.py --instances-file instances.txt --region us-east-1 --profile myawsprofile

****Spot-check one instance (optional):****

aws ec2 describe-instances \

--profile myawsprofile \

--region us-east-1 \

--instance-ids i-0123456789abcdef0 \

--query 'Reservations[0].Instances[0].MetadataOptions' \

--output json

If any instances cannot be remediated safely (design constraints), ****submit an Exception Request (TBD)**** for those resources.

### **Completion Check**

* IaC prevents new IMDSv1 resources
* Existing instances are aligned via replacement or Python bulk remediation
* Wiz shows findings as ****Resolved**** or ****No longer applicable****