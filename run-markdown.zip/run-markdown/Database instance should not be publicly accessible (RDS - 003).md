![A green leaf on a black background

AI-generated content may be incorrect.](data:image/png;base64...)

**Cloud Security Posture Management**

**Runbook – Remediation**

|  |  |  |
| --- | --- | --- |
| **Control Id** | **Control Name** | **Severity** |
| **RDS - 003** | **Database instance should not be publicly accessible** | **High** |

Version 1.0

Table of Contents

[1. Overview 3](#_Toc228789405)

[2. Objective 3](#_Toc228789406)

[3. Triage Process 3](#_Toc228789407)

[3.1 Identify Affected Users (Wiz) 4](#_Toc228789408)

[3.2 Validate, Usage and Impact 4](#_Toc228789409)

[4. Manual Mitigation – AWS Console 4](#_Toc228789410)

[4.1 Disable Public Accessibility 4](#_Toc228789411)

[5. Mitigation – AWS CLI 5](#_Toc228789412)

[6. Mitigation Using Terraform (IaC) 5](#_Toc228789413)

[6.1 Enforce Private Database Configuration 5](#_Toc228789414)

[6.2 Recommended Terraform Workflow 6](#_Toc228789415)

[7. Mitigation Using CloudFormation (IaC) 6](#_Toc228789416)

[8. Document Exception 6](#_Toc228789417)

[9. Detective Control 7](#_Toc228789418)

[10. Validation and Success Criteria 7](#_Toc228789419)

## 1. Overview

**Detection Tool**: Wiz Cloud Security Platform

**Hyperlink to the Rule**: [Cloud Configuration Findings | Wiz](https://app.wiz.io/findings/configuration-findings/cloud#%7E%28filters%7E%28status%7E%28equals%7E%28%7E%27OPEN%29%29%7Erule%7E%28equals%7E%28%7E%27ea53c934-0178-4634-b52e-5f1cc8edece4%29%29%29%7Eentity%7E%28%7E%29%29)

**Description**

This control identifies database instances configured as publicly accessible, meaning they can receive network traffic directly from the internet. Publicly accessible databases significantly increase the risk of unauthorized access, brute force attacks, data exfiltration, and exploitation of database vulnerabilities.

Databases are intended to reside within private network boundaries and be accessed only through trusted application components or controlled administrative paths. Exposing a database directly to the internet violates AWS security best practices and common compliance standards.

This enforces network segmentation and secure database exposure by ensuring that database instances are deployed in private subnets and are not publicly reachable.

This control is detective in nature, as AWS allows databases to be marked as public unless explicitly restricted. Wiz continuously evaluates database network settings to identify publicly accessible instances and generate findings.

## 2. Objective

The objective of this runbook is to define a standardized remediation process for database instances that are publicly accessible, as detected by the Wiz Cloud Security Platform.

Publicly accessible databases:

* Increase exposure to external threats
* Bypass network level defense in depth controls
* Violate organizational security and compliance standards

This runbook provides guidance to:

* Validate public accessibility findings
* Identify affected database instances
* Remove public exposure safely
* Handle approved exceptions with compensating controls

The goal is to ensure all database instances are deployed in private networks and are not publicly accessible, unless explicitly approved.

## 3. Triage Process

Please Refer to the below mentioned document:

[Master+Template+-+Remediation+SOP.docx](https://cargillonline.sharepoint.com/%3Aw%3A/r/sites/GIS-ADC-CloudSecurityTeam-TeamDiscussions-Private/_layouts/15/Doc.aspx?sourcedoc=%7B78D12AE6-08C4-4A84-AB4A-348A3A0F0F82%7D&file=Master%2BTemplate%2B-%2BRemediation%2BSOP.docx&action=default&mobileredirect=true)

### 3.1 Identify Affected Users (Wiz)

Navigate to Wiz → Cloud Configuration Findings.

1. Navigate to Wiz → Cloud Configuration Findings
2. Filter by rule “Database Instance Should Not Be Publicly Accessible”
3. Export the list of affected resources

Collect the following details:

* Database identifier
* AWS Account ID
* Database engine (RDS, Aurora, etc.)
* Public accessibility flag
* Subnet group
* VPC and security group configuration
* Application / business owner

### 3.2 Validate, Usage and Impact

Before remediation:

* Confirm whether public access is intentional
* Identify application or integration dependencies
* Validate database access paths through application tiers or VPNs

Note: Removing public accessibility may impact applications or external integrations that rely on direct database access.

## 4. Manual Mitigation – AWS Console

### 4.1 Disable Public Accessibility

This action is recommended and requires a database modification.

Steps:

1. Navigate to AWS Console → RDS → Databases
2. Select the affected database instance
3. Click Modify
4. Under Connectivity settings, configure:

* **Public access: No**

1. Review and update network-level controls:

a. Security Group (SG) Review

* Navigate to EC2 → Security Groups
* Identify the SG attached to the database
* Check Inbound Rules:
  + - * + If rule allows 0.0.0.0/0 or ::/0, this means open to public internet
    - Modify rules:
      * + Allow only specific application servers / private CIDR ranges
        + Example:

Allowed: 10.0.0.0/16 (VPC CIDR)

Not Allowed: 0.0.0.0/0

* + - Ensure the database is deployed in a private subnet

Verify:

* + - Subnet does NOT have route to Internet Gateway (IGW)
    - Route table should NOT contain:
      * + 0.0.0.0/0 → IGW

If required:

Move DB to private subnet group

1. Apply changes:
   * Immediately OR
   * During the next maintenance window

Note: Please check the VPC in the VPC the setting can be assigned as **Block public access NO.**

**Result:**

## Database is no longer publicly accessible

## Access is restricted to internal VPC network only

## Security Groups allow only authorized sources

## No internet exposure via subnet routing

## 5. Mitigation – AWS CLI

Describe Database Instance

|  |
| --- |
| aws rds describe-db-instances \  --db-instance-identifier <DB\_IDENTIFIER> |

Disable Public Accessibility

|  |
| --- |
| aws rds modify-db-instance \  --db-instance-identifier <DB\_IDENTIFIER> \  --publicly-accessible false \  --apply-immediately |

## 6. Mitigation Using Terraform (IaC)

Terraform enforces remediation by explicitly disabling public access.

### 6.1 Enforce Private Database Configuration

|  |
| --- |
| resource "aws\_db\_instance" "this" {  identifier = "example-db"  publicly\_accessible = false  db\_subnet\_group\_name = aws\_db\_subnet\_group.private.name  } |

### 6.2 Recommended Terraform Workflow

1. Wiz identifies publicly accessible database
2. Security validates business dependency
3. Terraform configuration is updated
4. terraform plan is reviewed and approved
5. terraform apply enforces private access

## 7. Mitigation Using CloudFormation (IaC)

CloudFormation remediation is enforced by setting the PubliclyAccessible property to false.

YAML:

|  |
| --- |
| DatabaseInstance:  Type: AWS::RDS::DBInstance  Properties:  PubliclyAccessible: false  DBSubnetGroupName: !Ref PrivateDBSubnetGroup |

Recommended CloudFormation Workflow

* Wiz identifies publicly accessible DB
* Security validates impact
* Template is updated to disable public access
* Change set is reviewed
* Stack update is executed

## 8. Document Exception

Exceptions should be rare, time bound and formally approved.

Required documentation:

* Business justification
* Reason public access is required
* Approver name and approval date
* Exception expiry date
* Compensating controls (IP allow listing, TLS, monitoring)

## 9. Detective Control

AWS does not prevent databases from being publicly accessible by default.

Detection is performed using:

* Database networking and visibility evaluation
* Wiz Cloud Security Platform analysis

Wiz continuously evaluates database instances for public accessibility and generates findings where exposure is detected.

## 10. Validation and Success Criteria

Successful remediation is confirmed when:

* Wiz findings for publicly accessible databases are reduced
* Database instances are no longer internet exposed
* Approved exceptions are documented and reviewed periodically