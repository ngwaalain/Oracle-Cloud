![](data:image/png;base64...)
**Cloud Security Posture Management**

**Runbook – Remediation**

|  |  |  |
| --- | --- | --- |
| **Control Id** | **Control Name** | **Severity** |
| **Snapshot-003** | *EBS Volume Snapshot should be encrypted* | **Medium** |

Version 1.0

#

Table of Contents

[1. Overview 1](#_Toc1005722881)

[Description 2](#_Toc1948753549)

[2. Objective 2](#_Toc296016104)

[3. Triage Process 3](#_Toc135498516)

[3.1 Identify Affected Snapshots (Wiz) 3](#_Toc1617050581)

[3.2 Categorize Findings 3](#_Toc1193754084)

[4. Manual Mitigation – AWS Console 3](#_Toc277845825)

[4.1 Review Snapshot Encryption Status 4](#_Toc705628615)

[4.2 Create Encrypted Snapshot 4](#_Toc1619109802)

[5. Mitigation – AWS CLI 4](#_Toc79469509)

[6. Mitigation Using Terraform (IaC) 5](#_Toc277859257)

[7. Mitigation – CloudFormation Automation 5](#_Toc1523074009)

[8. Document Exception 6](#_Toc1929872646)

[9. Preventive Control 6](#_Toc250417468)

[10. Validation and Success Criteria 6](#_Toc1528122000)

# 1. Overview

**Detection Tool:** Wiz Cloud Security Platform

**Hyperlink to the Rule:** [Cloud Configuration Rules – Wiz](https://app.wiz.io/policies/cloud-configuration-rules#%7E%28cloudConfigurationRule%7E%273ff7127e-0a07-4082-80df-02db44058080%29)

**Rule Type:** Wiz Custom Configuration Rule

Description**:**

This control evaluates whether **Amazon Elastic Block Store (EBS) snapshots are encrypted at rest**, ensuring that data captured from EBS volumes is protected throughout its lifecycle. The rule identifies situations where an EBS snapshot is created or retained without encryption enabled, which may result in sensitive application or infrastructure data being stored in an unprotected state.

Unencrypted EBS snapshots pose an increased security risk as they can be **copied, shared across AWS accounts, or restored into new volumes** without enforcing encryption, potentially leading to unauthorized data access or unintended data exposure. Such risks are amplified in environments with automated snapshot creation, cross region replication, or shared operational workflows.

The combined logic of these rules is designed to provide comprehensive coverage by ensuring that:

* Snapshots derived from both **encrypted and unencrypted EBS volumes** are evaluated for encryption compliance
* **Standalone, manually created, or legacy snapshots** are not overlooked due to historical configurations or process gaps
* Encryption requirements are enforced consistently across **all AWS accounts and regions**, regardless of snapshot source or creation method
* Snapshot handling and retention practices align with organizational security baselines, regulatory requirements, and audit expectations

By enforcing encryption on all EBS snapshots, this control helps prevent sensitive data leakage, reduces the risk associated with snapshot reuse or sharing, and strengthens the overall data at rest protection posture within the AWS environment.

# 2. Objective

The objective of this control is to **ensure all Amazon EBS snapshots are encrypted**, protecting sensitive data at rest and reducing the risk of unauthorized access or data leakage.

Specifically, this control aims to:

* Identify unencrypted EBS snapshots across all AWS accounts and regions
* Remediate legacy or newly created unencrypted snapshots
* Ensure encryption is consistently applied, regardless of snapshot source (volume-based or manual)
* Align snapshot management practices with organizational security and compliance standards

By enforcing encryption on EBS snapshots, this control reduces the likelihood of sensitive data leakage while strengthening the overall cloud data protection‑ posture.

# 3. Triage Process

Please Refer to the below mentioned document:
[Master+Template+-+Remediation+SOP.docx](https://cargillonline.sharepoint.com/%3Aw%3A/r/sites/GIS-ADC-CloudSecurityTeam-TeamDiscussions-Private/_layouts/15/Doc.aspx?sourcedoc=%7B78D12AE6-08C4-4A84-AB4A-348A3A0F0F82%7D&file=Master%2BTemplate%2B-%2BRemediation%2BSOP.docx&action=default&mobileredirect=true)

## 3.1 Identify Affected Snapshots (Wiz)

1. Navigate to **Wiz → Cloud Configuration Findings**
2. Filter by rules:
   * EBS Volume Snapshot should be encrypted
3. Identify impacted resources:
   * Snapshot ID
   * AWS Account ID
   * Region
   * Encryption status
   * Source EBS volume (if applicable)

## 3.2 Categorize Findings

**Category A – Approved & Controlled**

* Snapshot required temporarily for operational or migration purposes
* Compensating controls documented

**Category B – Requires Remediation**

* Unencrypted snapshots containing workload or application data
* Snapshots actively referenced or shared

**Category C – Not Required**

* Orphaned or obsolete snapshots
* Snapshots pending deletion

# 4. Manual Mitigation – AWS Console

## 4.1 Review Snapshot Encryption Status

1. Navigate to **AWS Console → EC2 → Snapshots**
2. Select the affected snapshot
3. Review the **Encryption** field

## 4.2 Create Encrypted Snapshot

Note: Encryption cannot be enabled on an existing snapshot. A new encrypted copy must be created.

1. Select the unencrypted snapshot
2. Choose **Actions → Copy Snapshot**
3. Enable **Encryption** and select an appropriate KMS key
4. Create the encrypted snapshot
5. Update dependencies to reference the encrypted snapshot
6. Delete the unencrypted snapshot (if approved)

**Result**:

* Data is protected using encryption
* Wiz finding is resolved

# 5. Mitigation – AWS CLI

Note: Existing EBS snapshots cannot be encrypted in place. An encrypted copy must be created.

* Identify the unencrypted snapshot:

|  |
| --- |
| aws ec2 describe-snapshots --snapshot-ids <SNAPSHOT\_ID> |

* Create an encrypted copy of the snapshot:

|  |
| --- |
| aws ec2 copy-snapshot \  --source-region <REGION> \  --source-snapshot-id <SNAPSHOT\_ID> \  --encrypted \  --kms-key-id <KMS\_KEY\_ID> \  --description "Encrypted copy of <SNAPSHOT\_ID>" |

* Verify the encryption status of the new snapshot:

|  |
| --- |
| aws ec2 describe-snapshots --snapshot-ids <NEW\_SNAPSHOT\_ID> |

Update dependent EBS volumes, AMIs, or workflows to use the encrypted snapshot.

* Delete the unencrypted snapshot (if approved):

|  |
| --- |
| aws ec2 delete-snapshot --snapshot-id <SNAPSHOT\_ID> |

**Result**
The snapshot is encrypted at rest, and the Wiz finding is resolved.

# 6. Mitigation Using Terraform (IaC)

Terraform can be used to remediate unencrypted EBS snapshots **indirectly** by enforcing encryption during snapshot copy and future snapshot creation workflows.

Terraform cannot encrypt an existing snapshot directly. Encryption is achieved through snapshot copy or by enforcing encrypted volume standards.

**Encrypted Snapshot Copy**

|  |
| --- |
| resource "aws\_ebs\_snapshot\_copy" "encrypted\_snapshot" {    source\_snapshot\_id = var.source\_snapshot\_id    source\_region      = var.source\_region    encrypted          = true    kms\_key\_id          = var.kms\_key\_id    tags = {      Name = "Encrypted-EBS-Snapshot"    }  } |

**Preventive Terraform Controls (Recommended)**

Enforce encrypted EBS volumes:

|  |
| --- |
| resource "aws\_ebs\_volume" "secure\_volume" {    encrypted = true    kms\_key\_id = var.kms\_key\_id  } |

**Result:**
Snapshot encryption is enforced through infrastructure standards, reducing the likelihood of future non-compliant findings.

# 7. Mitigation – CloudFormation Automation

For bulk or recurring remediation, use an **AWS CloudFormation template** that deploys automation (e.g., Step Functions) to:

* Identify unencrypted snapshots
* Copy snapshots with encryption enabled
* Optionally delete legacy unencrypted snapshots

**Result**:

* Scalable and consistent remediation
* Reduced risk of recurrence

# 8. Document Exception

Use only if snapshot encryption cannot be performed.

Required Details:

* Business justification
* Snapshot ID and AWS account ID
* Approver name and approval date
* Expiry or review date
* Compensating controls (restricted sharing, monitoring)
* **Exception Status: TBD**

# 9. Preventive Control

* Enforce encryption on all EBS snapshots by default
* Use encrypted EBS volumes to ensure downstream snapshot encryption
* Periodically review snapshot encryption status using Wiz
* Remove legacy or unused snapshots

# 10. Validation and Success Criteria

The control is effective when:

* No unencrypted EBS snapshots exist across monitored AWS accounts
* All exceptions are formally approved and documented
* Wiz reports no open findings for snapshot encryption rules