![](data:image/png;base64...)

**Cloud Security Posture Managment**

**Runbook – Remediation**

|  |  |  |
| --- | --- | --- |
| **Control Id** | **Control Name** | **Severity** |
| **xxx-xxx** | **Title - Hyperlink** | **xxx** |

**Version**

**Table of Content**

[Approaches Runbook 1](#_Toc165542228)

[Remediation Approach Overview 1](#_Toc1860595968)

[Approach 1 — Infrastructure as Code (IaC) (Primary) 2](#_Toc974916705)

[Approach 2 — Scripted Bulk Remediation (Go / Python) (Secondary) 2](#_Toc1537347275)

[Approach 3 — Wiz “Remediate” Action (When Available) 3](#_Toc174757064)

[Exception Reminder 3](#_Toc1597260625)

## Control Description

## Risk

## Approaches Runbook

This runbook describes how application teams should approach remediation of cloud configuration findings, independent of service or resource type.

It focuses on remediation methods, not specific control implementations.

## Remediation Approach Overview

Use the remediation path selected during triage (per the [**Master SOP**](https://tgrc-cargill.atlassian.net/wiki/spaces/CSE/pages/2034958339/Master%2BTemplate%2B-%2BRemediation%2BSOP)). Pick the option that is least disruptive and scales best for the finding and the affected resources.

Not every finding will be resolved using a single approach. It’s common to combine:

* **IaC to prevent recurrence**, and
* **Scripted or Wiz remediation** to clean up existing non-compliant resources.

### Approach 1 — Infrastructure as Code (IaC) (Primary)

Use IaC when the affected resource(s) are created or managed via Terraform (preferred for long-term prevention).

High-level steps:

1. Locate the Terraform repo/module that creates or manages the resource.
2. Identify the misconfiguration in code (missing config, insecure default, optional flag that should be enforced).
3. Confirm the change is safe (no expected app breakage, dependency issues, or deployment workflow conflicts).
4. Implement the fix in IaC and deploy through the standard pipeline.
5. If the finding cannot be fixed safely through IaC for this resource, **submit an Exception Request (TBD)** and document why.

Notes:

* IaC fixes stop new non-compliant resources from being created.
* Existing non-compliant resources may remain until replaced or bulk-remediated (see Scripted approach).

### Approach 2 — Scripted Bulk Remediation (Go / Python) (Secondary)

Use scripts when:

* IaC is already fixed (or cannot reach existing resources quickly), and
* you need to remediate many existing non-compliant resources without clicking one-by-one.

High-level steps:

1. Export or collect the target resource list from Wiz (or query by account/tags/service), then confirm scope.
2. Decide the remediation action the script will apply (based on the control intent and approved baseline).
3. Implement or reuse a Go/Python script that:
   * Supports a dry-run / preview mode
   * Logs actions taken (resource id, account, before/after state)
   * Has safety checks (scope limiting, allowlist tags/accounts, retries)
4. Run the script locally using the AWS CLI, with appropriately scoped credentials.
   * AWS CLI must be configured prior to execution (link to setup documentation to be added).
5. Re-check findings in Wiz to confirm bulk remediation took effect.
6. If any resources cannot be remediated safely by script, **submit an Exception Request (TBD)** for those cases and document why.

Notes:

* Scripted remediation is for existing resources.
* IaC remains the long-term source of truth to prevent drift.

### Approach 3 — Wiz “Remediate” Action (When Available)

Use Wiz remediation when:

* The “Remediate” action is available for the rule, and
* the change is understood and safe for the application/resource context.

High-level steps (Wiz UI):

1. Open the finding in Wiz and review affected resources (confirm you’re targeting the correct scope).
2. Review the rule details and proposed remediation (what will change).
3. Select the affected resources (single or bulk selection if supported).
4. Click **Remediate**.
5. Follow the prompts (confirm action / choose parameters if Wiz asks for any).
6. Monitor remediation progress in Wiz (or in the linked automation workflow if Wiz provides one).
7. Re-check the finding status in Wiz after completion.
8. If “Remediate” is not available, not compatible, or would cause disruption, switch to IaC or Scripted remediation. If it still cannot be remediated safely, **submit an Exception Request (TBD)**.

Notes:

* Wiz remediation is a **tool option**, not the default strategy.
* Prefer IaC for prevention and repeatability.

### Exception Reminder

If a finding cannot be remediated safely due to design, operational constraints, or business need, submit an **Exception Request (TBD)** and document the reason. Exceptions should be time-bound where possible.