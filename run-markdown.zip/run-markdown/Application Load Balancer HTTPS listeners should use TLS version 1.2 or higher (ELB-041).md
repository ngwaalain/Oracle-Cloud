![A green leaf on a black background

AI-generated content may be incorrect.](data:image/png;base64...)

**Cloud Security Posture Management**

**Runbook – Remediation**

|  |  |  |
| --- | --- | --- |
| **Control Id** | **Control Name** | **Severity** |
| **ELB-041** | **Application Load Balancer HTTPS listeners should use TLS version 1.2 or higher** | **Medium** |

Version 1.0

Table of Contents

[1. Overview 3](#_Toc228786468)

[2. Objective 3](#_Toc228786469)

[3. Triage Process 4](#_Toc228786470)

[3.1 Identify Affected Environments (Wiz) 4](#_Toc228786471)

[3.2 Prerequisites 4](#_Toc228786472)

[4. Manual Mitigation – AWS Console 4](#_Toc228786473)

[4.1 Navigate and Locate to the load balancer: 4](#_Toc228786474)

[4.2 Review and Modify the load balancer listners 5](#_Toc228786475)

[4.3 Repeat and Verify the changes 5](#_Toc228786476)

[5. Mitigation – AWS CLI 5](#_Toc228786477)

[6. Mitigation Using CloudFromation (IaC) 8](#_Toc228786478)

[7. Preventive Control – AWS Config Managed Rule 9](#_Toc228786479)

[8. Validation and Success Criteria 9](#_Toc228786480)

# 1. Overview

**Detection Tool:** Wiz Cloud Security Platform

**Hyperlink to the Rule**: [Cloud Configuration Findings | Wiz](https://app.wiz.io/findings/configuration-findings/cloud#%7E%28filters%7E%28status%7E%28equals%7E%28%7E%27OPEN%29%29%7Erule%7E%28equals%7E%28%7E%276f94fd9d-098a-48aa-bb79-d2ebe605535d%29%29%29%7Eentity%7E%28%7E%29%29)

**AWS Config Managed Rule Name**: elb-tls-https-listeners

This control identifies Application Load Balancer (ALB) HTTPS listeners that allow deprecated TLS versions (TLS 1.0 or TLS 1.1). Older TLS versions contain known cryptographic weaknesses and do not meet modern security or compliance standards.

Transport Layer Security (TLS) is a cryptographic protocol that secures data in transit between two systems (for example, a user’s browser and a web application). It is the technology behind HTTPS and is widely used for web traffic, APIs, email, and cloud services.

TLS provides three core security guarantees:

**Confidentiality** – Data is encrypted so attackers cannot read it

**Integrity** – Data cannot be altered without detection

**Authentication** – The server proves its identity using digital certificates

TLS is the successor to SSL and is standardized by the IETF. The current recommended versions are TLS 1.2 and TLS 1.3, with TLS 1.3 being the most secure and modern version

# 2. Objective

This runbook defines the standardized process to identify, remediate, and prevent Application Load Balancer HTTPS listeners from using TLS versions lower than 1.2.

The objective of this runbook is to define a standardized remediation process for Application Load Balancer HTTPS listeners that are not enforcing TLS version 1.2 or higher, as detected by the Wiz Cloud Security Platform.

Using insecure TLS versions:

* Weakens encryption for data in transit
* Increases exposure to man in the middle attacks
* Violates AWS recommended security practices

This runbook provides guidance to:

* Validate insecure TLS findings
* Identify affected ALB listeners
* Update TLS security policies to TLS 1.2+
* Manage approved exceptions with compensating controls

The goal is to ensure all ALB HTTPS listeners enforce TLS 1.2 or higher across AWS environments.

# 3. Triage Process

Please Refer to the below mentioned document:

[Master+Template+-+Remediation+SOP.docx](https://cargillonline.sharepoint.com/%3Aw%3A/r/sites/GIS-ADC-CloudSecurityTeam-TeamDiscussions-Private/_layouts/15/Doc.aspx?sourcedoc=%7B78D12AE6-08C4-4A84-AB4A-348A3A0F0F82%7D&file=Master%2BTemplate%2B-%2BRemediation%2BSOP.docx&action=default&mobileredirect=true)

### 3.1 Identify Affected Environments (Wiz)

Navigate to Wiz → Cloud Configuration Findings and filter by the rule “Application Load Balancer HTTPS listeners should use TLS version 1.2 or higher”. Export the list of affected resources.

Collect the following details:

* Load Balancer name
* AWS Account ID
* Listener ARN
* Listener port (HTTPS – typically 443)
* Current SSL policy
* Application owner

### 3.2 Prerequisites

IAM permissions

|  |
| --- |
| elasticloadbalancing:ModifyListener  elasticloadbalancing:DescribeListeners |

Validate Client and Business Impact

Before remediation:

* Identify any legacy client dependencies
* Validate protocol compatibility with application owners
* Review planned maintenance windows if required

**Note**: Enforcing TLS 1.2+ may break legacy clients that do not support modern cryptographic protocols.

# 4. Manual Mitigation – AWS Console

### 4.1 Navigate and Locate to the load balancer:

* AWS consoleà EC2 à Load balancers à Identify the desired load balancer (Affected resources file) à Identify the Listners and rules in the bottom.

### 4.2 Review and Modify the load balancer listners

* Identify the Listners and select à Look for HTTPS (443 port) à Listners need to be updated with lastest TLS Version
* You will find Rules à Move to Security à Update the security policy à Edit the policyà to the latest TLS (ELBSecurityPolicy-TLS-1-2-\*, ELBSecurityPolicy-TLS-1-3-\*) à Save

**Note**: Review Other Settings:

* Ensure all other listener settings remain as needed
* Verify the SSL certificate is still correctly configured

### 4.3 Repeat and Verify the changes

If you find other HTTPS listners services in the same load balancer please update the same as of above process.

Return to listners tab check the security policy is more that TLS 1.2  Test the application is working.

Note:

Before Making Changes:

* Test the new security policy in a non-production environment first
* Some older clients may not support TLS 1.2+ and could lose connectivity
* Consider your application's compatibility requirement
* Identify the load balancer and listner

# 5. Mitigation – AWS CLI

# Set variables for easier reference

|  |
| --- |
| ALB\_ARN="LOAD\_BALANCER\_NAME "  REGION="REGION\_NAME" |

# Get load balancer details

|  |
| --- |
| aws elbv2 describe-load-balancers \  --load-balancer-arns $ALB\_ARN \  --region $REGION |

* **List All HTTPS Listners**

# Get all listeners for the load balancer

|  |
| --- |
| aws elbv2 describe-listeners \  --load-balancer-arn $ALB\_ARN \  --region $REGION \  --query 'Listeners[?Protocol==`HTTPS`].[ListenerArn,Port,Protocol,SslPolicy]' \  --output table |

* **Check current SSL Policies**

# Get detailed SSL policy information for HTTPS listeners

|  |
| --- |
| aws elbv2 describe-listeners \  --load-balancer-arn $ALB\_ARN \  --region $REGION \  --query 'Listeners[?Protocol==`HTTPS`]' \  --output json | jq '.[] | {ListenerArn: .ListenerArn, Port: .Port, SslPolicy: .SslPolicy}' |

* **Identify compliant SSL Policies**

# List available SSL policies that support TLS 1.2+

|  |
| --- |
| aws elbv2 describe-ssl-policies \  --region $REGION \  --query 'SslPolicies[?contains(SupportedProtocols, `TLSv1.2`) && !contains(SupportedProtocols, `TLSv1`) && !contains(SupportedProtocols, `TLSv1.1`)].Name' \  --output table |

* **Update HTTPS listners**

# Update to use TLS 1.2+ policy

|  |
| --- |
| aws elbv2 modify-listener \  --listener-arn $LISTENER\_ARN \  --ssl-policy ELBSecurityPolicy-TLS13-1-2-2021-06 \  --region $REGION |

• **Verify**

# Verify all HTTPS listeners now use compliant SSL policies

|  |
| --- |
| aws elbv2 describe-listeners \  --load-balancer-arn $ALB\_ARN \  --region $REGION \  --query 'Listeners[?Protocol==`HTTPS`].[ListenerArn,Port,SslPolicy]' \  --output table |

• **Test**

# Get the load balancer DNS name

|  |
| --- |
| ALB\_DNS=$(aws elbv2 describe-load-balancers \  --load-balancer-arns $ALB\_ARN \  --region $REGION \  --query 'LoadBalancers[0].DNSName' \  --output text) |

# Test TLS version using OpenSSL (if available)

echo "Testing TLS 1.2 support:"

|  |
| --- |
| echo | openssl s\_client -connect $ALB\_DNS:443 -tls1\_2 -servername $ALB\_DNS 2>/dev/null | grep "Protocol" |

echo "Testing TLS 1.1 (should fail):"

|  |
| --- |
| echo | openssl s\_client -connect $ALB\_DNS:443 -tls1\_1 -servername $ALB\_DNS 2>/dev/null | grep "Protocol" || echo "TLS 1.1 correctly rejected" |

# 6. Mitigation Using CloudFromation (IaC)

CloudFormation remediation is enforced by updating the Listener SSLPolicy property.

YAML:

|  |
| --- |
| HTTPSListener:  Type: AWS::ElasticLoadBalancingV2::Listener  Properties:  LoadBalancerArn: !Ref ApplicationLoadBalancer  Port: 443  Protocol: HTTPS  Certificates:  - CertificateArn: !Ref ALBCertificate  SslPolicy: ELBSecurityPolicy-TLS13-1-2-2021-06 |

**Recommended CloudFormation Workflow**

* Wiz identifies ALBs using weak TLS
* Security validates client impact
* Listener policy is updated
* Change set is reviewed
* Stack update is executed

# 7. Mitigation Using CloudFromation (IaC)

|  |
| --- |
| resource "aws\_lb\_listener" "https\_listener" {  load\_balancer\_arn = aws\_lb.app\_lb.arn  port = 443  protocol = "HTTPS"  ssl\_policy = "ELBSecurityPolicy-TLS13-1-2-2021-06"  certificate\_arn = aws\_acm\_certificate.app\_cert.arn  default\_action {  type = "forward"  target\_group\_arn = aws\_lb\_target\_group.app\_tg.arn  }  } |

# 8. Preventive Control – AWS Config Managed Rule

Enable AWS Config managed rule elb-tls-https-listeners to continuously detect.

Steps:

1. Navigate to AWS Config
2. Add Rule → AWS Managed Rule
3. Select elb-tls-https-listeners
4. Save and enable the rule

Result:

* Continuous detection inside AWS
* Independent evidence for audits

# 9. Validation and Success Criteria

Reduction in Wiz failed checks, no service disruption, and continuous compliance visibility via AWS Config.