# Master Template - Remediation SOP

# Cloud Configuration Findings - Master Template

**👥 Audience:** Application teams, Cloud Platform, Cloud Security
**🛠️ Tooling:** Wiz (Default & Custom Rules)
**📋 Compliance Mapping:** CSA → Cloud Security Navigator (CSN) → Wiz rule

![](data:image/png;base64...)

## Purpose

This doc explains how cloud configuration findings should be reviewed and remediated when identified in Wiz.

We aim to make remediation:

* ✅ Easy to understand
* ✅ Consistent across teams
* ✅ Safe for applications
* ✅ Aligned with CSA / CCM expectations

## Scope

Applies to:

* All cloud configuration findings from Wiz (default and custom rules)
* All Cargill AWS environments (prod, stage and dev)
* All app teams and cloud platform teams are responsible for their own resources

**Note:** This doesn't prescribe one remediation method. Different applications may handle the same finding differently based on context.

## Guiding Principles (Read This First)

Not every finding means "**fix it immediately.**"

Before making changes, ask:

* Is this resource still active?
* Is the configuration intentional?
* What's the impact of changing it?
* Are there existing compensating controls?

**Goal:** Secure and functional, not "green at all costs."

## Roles & Responsibilities

|  |  |
| --- | --- |
| **Role** | **What They Do** |
| **Wiz Platform** | Detects and reports findings |
| **Cloud Security** | Provides guidance and clarification; Tracks control alignment ; Tracks remediation metrics |
| **Application/Cloud Platform Team** | Reviews and implements remediation |

📘 Detailed RACI and escalation paths are separate here (TBD).

## Access Cloud Configuration Findings

1. Log in to [Wiz](https://app.wiz.io/)
2. Go to: Findings → [Cloud Configuration Findings](https://app.wiz.io/findings/configuration-findings/cloud#%7E%28filters%7E%28status%7E%28equals%7E%28%7E%27OPEN%29%29%7EcloudPlatform%7E%28equals%7E%28%7E%27AWS%29%29%29%29)
3. Find the issue/non-compliant rule using: Rule name and/or Resource name and/or Account/subscription
4. Open the rule to see:
   * Affected resource(s)
   * Why it was flagged
   * Evidence and timestamps
   * Suggested fix (if available)

**Sample Cloud Configuration view with filters to identify all mis-configurations**

![](data:image/png;base64...)

**Sample view of rule with it affected resources**

![](data:image/png;base64...)

**Sample view of resource with auto-remediation functionality: Findings > Cloud Configuration Findings > Rule > Affected resource > remediate**

![](data:image/png;base64...)

### Using Mika AI to Simplify Control and Finding Insights

Complete and enter the below prompt into Mika AI step after step. (Mika does not support bulk requests)

|  |
| --- |
| * Identify the cloud configuration finding for: Control: <CONTROL\_NAME>  Finding: <FINDING\_NAME>  Resource: <RESOURCE\_ID / NAME>      * What is misconfigured (simple + technical explanation) * Why this is a security riskand what could happen if exploited (real-world impact) |

Identify the cloud configuration finding for:

Control: <CONTROL\_NAME>

Finding: <FINDING\_NAME>

Resource: <RESOURCE\_ID / NAME>

1. What is misconfigured (simple + technical explanation)

2. Why this is a security riskand what could happen if exploited (real-world impact)

## Remediation Review & Validation

Review findings and prioritize remediation based on **risk, impact (weight), and environment –** [Finding Management Tool](https://cargillonline.sharepoint.com/%3Ax%3A/r/sites/GIS-ADC-CloudSecurityTeam-TeamDiscussions-Private/Shared%20Documents/Team%20-%20Private/ADC-CloudSec/Cargill-CSPM-CSA-Framework/Finding%20Management%20Tool/CSPM_CSA_Master_Spreadsheet.xlsx?d=w7f71122843f8435e874f2619f33b1567&csf=1&web=1&e=QEQdIy)

Before acting:

* Is the resource still active?
* Is the configuration intentional?
* Does this match the application design?
* Is there an approved exception?

### Possible Outcomes:

* **Valid finding** → Plan remediation
* **False positive** → Document and follow Exception Process (TBD)
* **Accepted risk** → Ensure documented and time-bound

**If unsure:** Pause and ask **Cloud Security** before changing anything.

## Choosing a Remediation Approach

**No single required method**—use what fits your app.

### Options:

* **Infrastructure as Code (preferred)** – Terraform, CloudFormation, pipelines
* **Wiz-guided remediation** – When available and low risk
* **Scripted remediation** - Stand-alone scripts where applicable
* **Manual changes** – For one-off or urgent needs

🔄 Reflect manual changes back into IaC when possible to avoid drift.

## Validation & Closure

After fixing:

1. Re-check the resource in Wiz
2. Confirm the finding is Resolved or No longer applicable
3. Verify no application regression
4. Update documentation if necessary (run books/templates)
5. Update tracking metrics.

## References

* [Wiz Documentation](https://docs.wiz.io/docs/cloud-configuration-findings)
* [CSA CCM v.4.0.5 Cargill Framework](https://app.wiz.io/reports/compliance/framework/1fc18e57-d891-4bb0-b61f-7960da97b20e)
* [CSA Cloud Controls Matrix](https://cloudsecuritydocs.cglcloud.com/patterns/grc/cloud-compliance-framework.html?h=)
* [Cloud Security Navigator (CSN)](https://cloudsecuritydocs.cglcloud.com/architecture/framework/cloud-security-navigator.html?h=)

## 💬 Note

If something in Wiz doesn't make sense, **don't guess**.
Ask early, document decisions, and prioritize application stability alongside security.

**Last Updated:** 02/03/2026
**Owner:** Cloud Security Team
**Review Cycle:** Quarterly