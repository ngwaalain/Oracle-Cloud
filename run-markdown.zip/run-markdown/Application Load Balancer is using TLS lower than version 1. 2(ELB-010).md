![A green leaf on a black background

AI-generated content may be incorrect.](data:image/png;base64...)

**Cloud Security Posture Management**

**Runbook – Remediation**

|  |  |  |  |
| --- | --- | --- | --- |
| **Control Id** | **Control Name** |  | **Severity** |
| **ELB-010** | **Application Load Balancer is using TLS lower than version 1. 2** |  | **Medium** |

Version 1.0

Table of Contents

[1. Overview 3](#_Toc228788664)

[2. Objective 3](#_Toc228788665)

[3. Triage Process 4](#_Toc228788666)

[3.1 Identify Affected Environments (Wiz) 4](#_Toc228788667)

[3.2 Prerequisites 4](#_Toc228788668)

[4. Manual Mitigation – AWS Console 4](#_Toc228788669)

[4.1 Navigate and Locate to the load balancer: 4](#_Toc228788670)

[4.2 Review and Modify the load balancer listners 5](#_Toc228788671)

[4.3 Repeat and Verify the changes 5](#_Toc228788672)

[5. Mitigation – AWS CLI 6](#_Toc228788673)

[6. Using Terraform 9](#_Toc228788674)

[7. Mitigation Using CloudFormation (IaC) 9](#_Toc228788675)

[8. Document Exception 10](#_Toc228788676)

[9. Detective Control 11](#_Toc228788677)

[10. Validation and Success Criteria 11](#_Toc228788678)

# 1. Overview

**Detection Tool**: Wiz Cloud Security Platform

**Hyperlink to the Rule**: [Cloud Configuration Findings | Wiz](https://app.wiz.io/findings/configuration-findings/cloud#%7E%28filters%7E%28status%7E%28equals%7E%28%7E%27OPEN%29%29%7Erule%7E%28equals%7E%28%7E%27fbe8065d-2b40-4c6a-b6f5-faa0a7fbccee%29%29%29%7Eentity%7E%28%7E%29%7Etab%7E%27Remediation%29)

This control identifies Application Load Balancer (ALB) that allows deprecated TLS versions (TLS 1.0 or TLS 1.1). Older TLS versions contain known cryptographic weaknesses and do not meet modern security or compliance standards.

Transport Layer Security (TLS) is a cryptographic protocol that secures data in transit between two systems (for example, a user’s browser and a web application). It is the technology behind HTTPS and is widely used for web traffic, APIs, email, and cloud services.

TLS provides three core security guarantees:

**Confidentiality** – Data is encrypted so attackers cannot read it

**Integrity** – Data cannot be altered without detection

**Authentication** – The server proves its identity using digital certificates

TLS is the successor to SSL and is standardized by the IETF. The current recommended versions are TLS 1.2 and TLS 1.3, with TLS 1.3 being the most secure and modern version.

# 2. Objective

This runbook defines the standardized process to identify, remediate, and prevent Application Load Balancer listeners from using TLS versions lower than 1.2.

The objective of this runbook is to define a standardized remediation process for Application Load Balancers using TLS versions lower than 1.2, as detected by the Wiz Cloud Security Platform.

Using deprecated TLS versions:

* Weaken encryption of data in transit
* Increases exposure to man in the middle attacks
* Violates modern security baselines and compliance standards

This runbook provides guidance to:

* Validate TLS policy findings
* Identify affected ALB listeners
* Enforce secure TLS policies (TLS 1.2+)
* Manage approved exceptions with compensating controls

The goal is to ensure all ALB HTTPS listeners enforce TLS 1.2 or higher.

# 3. Triage Process

Please Refer to the below mentioned document:

[Master+Template+-+Remediation+SOP.docx](https://cargillonline.sharepoint.com/%3Aw%3A/r/sites/GIS-ADC-CloudSecurityTeam-TeamDiscussions-Private/_layouts/15/Doc.aspx?sourcedoc=%7B78D12AE6-08C4-4A84-AB4A-348A3A0F0F82%7D&file=Master%2BTemplate%2B-%2BRemediation%2BSOP.docx&action=default&mobileredirect=true)

### 3.1 Identify Affected Environments (Wiz)

Navigate to Wiz → Cloud Configuration Findings and filter by the rule “Application Load Balancer is using TLS lower than version 1. 2”. Export the list of affected resources.

Collect the following details:

* Load Balancer name
* AWS Account ID
* Listener port (typically 443)
* Current SSL policy
* Associated certificates
* Application owner

### 3.2 Prerequisites

IAM permissions for

|  |
| --- |
| elasticloadbalancing:ModifyListener  elasticloadbalancing:DescribeListeners |

Before remediation:

* Identify client or legacy dependencies requiring older TLS
* Confirm change window and business impact
* Validate supported TLS versions with application teams

**Note**: Enforcing TLS 1.2 may impact legacy clients or integrations that do not support modern protocols.

# 4. Manual Mitigation – AWS Console

### 4.1 Navigate and Locate to the load balancer:

AWS console EC2 Load balancers  Identify the desired load balancer (Affected resources file)  Identify the Listners and rules in the bottom.

Review the current listners

* HTTPS listeners using TLS versions below 1.2
* HTTP listeners that should be redirected to HTTPS (It is based on the application dependency)

### 4.2 Review and Modify the load balancer listners

* Identify the Listners and select 🡪 Look for HTTPS (443 port) 🡪 Listners need to be updated with lastest TLS Version
* You will find Rules🡪Move to Security 🡪 Update the security policy 🡪 Edit the policy 🡪 to the latest TLS (ELBSecurityPolicy-TLS-1-2-\*, ELBSecurityPolicy-TLS-1-3-\*) 🡪Save

Note: Review of other settings:

* Ensure all other listener settings remain as needed
* Verify the SSL certificate is still correctly configured

Convert HTTP to HTTPS

• Select HTTP 🡪Action 🡪Edit listner 🡪 Action type to HTTPS 🡪Port 443 (Redirection rule) 🡪Status code (HTTP 301) 🡪 Save

Example: Redirect to HTTPS://#{host}:443/#{path}?#{query}

Status code: HTTP\_301

### 4.3 Repeat and Verify the changes

If you find other HTTPS listners services in the same load balancer please update the same as of above process.

Return to listners tab🡪 check the security policy is more that TLS 1.2 🡪 Test the application is working.

Note:

Before Making Changes:

* Test the new security policy in a non-production environment first
* Some older clients may not support TLS 1.2+ and could lose connectivity
* Consider your application's compatibility requirements

# 5. Mitigation – AWS CLI

Identify the load balancer and listner

# Set variables for easier reference

|  |
| --- |
| ALB\_ARN="LOAD\_BALANCER\_NAME "  REGION="REGION\_NAME" |

# Get load balancer details

|  |
| --- |
| aws elbv2 describe-load-balancers \  --load-balancer-arns $ALB\_ARN \  --region $REGION  --output table |

• **List All HTTPS Listners**

# Get all listeners for the load balancer

|  |
| --- |
| aws elbv2 describe-listeners \  --load-balancer-arn $ALB\_ARN \  --region $REGION \  --query 'Listeners[?Protocol==`HTTPS`].[ListenerArn,Port,Protocol,SslPolicy]' \  --output table |

• **Check current SSL Policies**

# Get detailed SSL policy information for HTTPS listeners

|  |
| --- |
| aws elbv2 describe-listeners \  --load-balancer-arn $ALB\_ARN \  --region $REGION \  --query 'Listeners[?Protocol==`HTTPS`]' \  --output json | jq '.[] | {ListenerArn: .ListenerArn, Port: .Port, SslPolicy: .SslPolicy}' |

• **Identify compliant SSL Policies**

# List available SSL policies that support TLS 1.2+

|  |
| --- |
| aws elbv2 describe-ssl-policies \  --region $REGION \  --query 'SslPolicies[?contains(SupportedProtocols, `TLSv1.2`) && !contains(SupportedProtocols, `TLSv1`) && !contains(SupportedProtocols, `TLSv1.1`)].Name' \  --output table |

• **Update HTTPS listners**

# Update to use TLS 1.2+ policy

|  |
| --- |
| aws elbv2 modify-listener \  --listener-arn $LISTENER\_ARN \  --ssl-policy ELBSecurityPolicy-TLS13-1-2-2021-06 \  --region $REGION |

* **HTTP to HTTPS Redirects**

# Get HTTP listener ARNs

|  |
| --- |
| aws elbv2 describe-listeners \  --load-balancer-arn $ALB\_ARN \  --region $REGION \  --query 'Listeners[?Protocol==`HTTP`].ListenerArn' \  --output text |

Redirection Rule

|  |
| --- |
| aws elbv2 modify-listener \  --listener-arn "<HTTP\_LISTENER\_ARN>" \  --default-actions Type=redirect,RedirectConfig='{Protocol=HTTPS,Port=443,StatusCode=HTTP\_301}' \  --region us-east-1 |

• **Verify**

# Verify all HTTPS listeners now use compliant SSL policies

|  |
| --- |
| aws elbv2 describe-listeners \  --load-balancer-arn $ALB\_ARN \  --region $REGION \  --query 'Listeners[?Protocol==`HTTPS`].[ListenerArn,Port,SslPolicy]' \  --output table |

• **Test**

# Get the load balancer DNS name

|  |
| --- |
| ALB\_DNS=$(aws elbv2 describe-load-balancers \  --load-balancer-arns $ALB\_ARN \  --region $REGION \  --query 'LoadBalancers[0].DNSName' \  --output text) |

# Test TLS version using OpenSSL (if available)

echo "Testing TLS 1.2 support:"

|  |
| --- |
| echo | openssl s\_client -connect $ALB\_DNS:443 -tls1\_2 -servername $ALB\_DNS 2>/dev/null | grep "Protocol" |

echo "Testing TLS 1.1 (should fail):"

|  |
| --- |
| echo | openssl s\_client -connect $ALB\_DNS:443 -tls1\_1 -servername $ALB\_DNS 2>/dev/null | grep "Protocol" || echo "TLS 1.1 correctly rejected" |

# 6. Using Terraform

|  |
| --- |
| resource "aws\_lb\_listener" "https\_listener" {  load\_balancer\_arn = aws\_lb.app\_alb.arn  port = 443  protocol = "HTTPS"  ssl\_policy = "ELBSecurityPolicy-TLS13-1-2-2021-06"  certificate\_arn = var.certificate\_arn    default\_action {  type = "forward"  target\_group\_arn = aws\_lb\_target\_group.app\_tg.arn  }  } |

# 7. Mitigation Using CloudFormation (IaC)

CloudFormation remediation is enforced by updating the Listener SSLPolicy property.

YAML:

|  |
| --- |
| HTTPSListener:  Type: AWS::ElasticLoadBalancingV2::Listener  Properties:  LoadBalancerArn: !Ref ApplicationLoadBalancer  Port: 443  Protocol: HTTPS  Certificates:  - CertificateArn: !Ref ALBCertificate  SslPolicy: ELBSecurityPolicy-TLS13-1-2-2021-06 |

Recommended CloudFormation Workflow

* Wiz identifies ALBs using weak TLS
* Security validates client impact
* Listener policy is updated
* Change set is reviewed
* Stack update is executed

# 8. Document Exception

Exceptions should be temporary and business justified.

Required documentation:

* Business justification
* Legacy client or integration dependency
* Approver name and approval date
* Exception expiration date
* Migration or remediation plan

# 9. Detective Control

AWS does not automatically restrict TLS versions for ALB listeners.

Detection is performed using:

* ALB listener SSL policy evaluation
* Wiz Cloud Security Platform analysis

Wiz continuously evaluates listener configurations to identify ALBs allowing deprecated TLS versions.

# 10. Validation and Success Criteria

Reduction in Wiz failed checks, no service disruption, and continuous compliance visibility via AWS Config.

Successful remediation is achieved when:

* Wiz findings for this metric are reduced
* Affected ALBs enforce TLS 1.2 or higher
* Exceptions are documented and reviewed periodically