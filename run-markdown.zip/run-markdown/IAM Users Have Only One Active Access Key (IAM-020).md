![A green leaf on a black background

AI-generated content may be incorrect.](data:image/png;base64...)

**Cloud Security Posture Management**

**Runbook – Remediation**

|  |  |  |
| --- | --- | --- |
| **Control Id** | **Control Name** | **Severity** |
| **IAM-020** | **IAM Users Have Only One Active Access Key** | **Low** |

Version 1.0

Table of Contents

[1. Overview 3](#_Toc229574876)

[2. Objective 3](#_Toc229574877)

[3. Triage Process 4](#_Toc229574878)

[3.1 Identify Affected Users (Wiz) 4](#_Toc229574879)

[3.2 Mitigation Strategy 4](#_Toc229574880)

[3.3 Prerequisites 4](#_Toc229574881)

[4. Manual Mitigation – AWS Console 4](#_Toc229574882)

[4.1 Deactivate the access key: 4](#_Toc229574883)

[4.2 Deletion of access key: 5](#_Toc229574884)

[5. Mitigation – AWS CLI 5](#_Toc229574885)

[5.1 Identifying the access keys: 5](#_Toc229574886)

[5.2 Identify which key to keep: 5](#_Toc229574887)

[5.3 Co-ordinate with application teams: 6](#_Toc229574888)

[5.4 Deactivating the unused access key: 6](#_Toc229574889)

[5.5 Test the application functionality: 6](#_Toc229574890)

[5.6 Delete the inactive access key: 6](#_Toc229574891)

[6. Mitigation Using CloudFormation (IaC) 6](#_Toc229574892)

[7. Mitigation Using Terraform (IaC) 7](#_Toc229574893)

[7.1 Enforce Single Active Access Key 7](#_Toc229574894)

[7.2 Remove Additional Access Keys 8](#_Toc229574895)

[7.3 Conditional Key Creation (Best Practice) 9](#_Toc229574896)

[7.4 Key Rotation Strategy (Recommended) 9](#_Toc229574897)

[8: Document Exception 9](#_Toc229574898)

[9. Preventive Control – AWS Config Managed Rule 10](#_Toc229574899)

[10. Validation and Success Criteria 10](#_Toc229574900)

## 1. Overview

**Detection Tool**: Wiz Cloud Security Platform

**Hyperlink to the Rule**: [Cloud Configuration Findings | Wiz](https://app.wiz.io/findings/configuration-findings/cloud#%7E%28filters%7E%28status%7E%28equals%7E%28%7E%27OPEN%29%29%7Erule%7E%28equals%7E%28%7E%27641fabe5-a9da-4491-b419-836229bda57f%29%29%29%7EgroupBy%7E%28%7E%29%29)

**Description**:

This control identifies AWS IAM users that have more than one active access key associated with their identity. AWS security best recommends maintaining only one active access key per IAM user at any given time to reduce credential exposure and enforce proper key rotation.

Multiple active access keys increase the attack surface by allowing parallel credential misuse, unnoticed key compromise, and poor credential lifecycle management. Stale or forgotten access keys are a common root cause for unauthorized programmatic access and data exposure incidents.

This metric supports IAM access key hygiene and identity governance by ensuring that access keys are actively monitored, reviewed, and remediated where excessive keys exist.

This control is detective in nature, as AWS does not enforce a hard limit on the number of active access keys per IAM user. Wiz evaluates IAM credential reports to continuously identify users violating this best practice and generates actionable findings.

## 2. Objective

The objective of this runbook is to define a standardized remediation process for AWS IAM users that have more than one active access key, as detected by the Wiz Cloud Security Platform.

Maintaining multiple active access keys per user:

* Weakens credential rotation practices
* Increases the risk of compromised keys going undetected
* Violates AWS IAM security best practices and internal IAM policies

This runbook provides guidance to:

* Validate metric findings
* Identify unused or legacy access keys
* Safely deactivate or delete excess access keys
* Manage approved exceptions with compensating controls

The goal is to ensure all IAM users maintain only one active access key, unless a documented exception is approved.

## 3. Triage Process

Please Refer to the below mentioned document:

[Master+Template+-+Remediation+SOP.docx](https://cargillonline.sharepoint.com/%3Aw%3A/r/sites/GIS-ADC-CloudSecurityTeam-TeamDiscussions-Private/_layouts/15/Doc.aspx?sourcedoc=%7B78D12AE6-08C4-4A84-AB4A-348A3A0F0F82%7D&file=Master%2BTemplate%2B-%2BRemediation%2BSOP.docx&action=default&mobileredirect=true)

### 3.1 Identify Affected Users (Wiz)

Navigate to Wiz → Cloud Configuration Findings and filter by the rule “IAM Users Have Only One Active Access Key”. Export the list of affected IAM users.

Collect the following details: IAM username, AWS account ID, console last-used date, access key last-used dates, user creation date, and ownership tags.

### 3.2 Mitigation Strategy

* Allow maximum one active key per IAM user.
* Use the second key only temporarily during rotation.
* Immediately deactivate/delete unused keys.

### 3.3 Prerequisites

The user should have the below stated permission to do changes to access keys.

IAM permissions:

iam:ListAccessKeys

iam:UpdateAccessKey

iam:DeleteAccessKey

## 4. Manual Mitigation – AWS Console

### 4.1 Deactivate the access key:

This action is safe, reversible, and low risk

**Step 1**: Navigate to AWS Console → IAM → Users and select the affected IAM user reported by Wiz.

**Step 2**: Review Security Credentials to the access key should be able to find two access keys with an “Active” State.

Identifying which access key to disable

\*Check last used information

1. Review the last used column for each access key
2. Identify which key was used more recently or is currently in use
3. Consider deactivating the older or unused key first

\*Co-ordinate with application team

1. Contact the application teams using this IAM user
2. Verify which access key is currently in use
3. Plan the deactivation during a maintenance window if necessary

**Step 3**: Based on the above conclusion, please select the access key in the drop down to make the changes to key as Deactivate.

**Step 4**: Once the key is deactivated, monitor the functionality, services of the application, and logs of the application if any errors.

**Step 5**: Once the application is monitored for a week and once there is no impact in functionality, please delete the access key.

### 4.2 Deletion of access key:

Please make sure that the application is running without any issues and the key can be deleted.

Goto the IAM user àSecurity Credentials àSelect the access key that is in deactivated stateàDelete the key

## 5. Mitigation – AWS CLI

### 5.1 Identifying the access keys:

|  |
| --- |
| aws iam update-access-key --user-name <USERNAME> |

### 5.2 Identify which key to keep:

•Check access key usage

# Check last used information for each access key

|  |
| --- |
| aws iam get-access-key-last-used --access-key-id <ACCESS\_KEY\_ID\_1>  aws iam get-access-key-last-used --access-key-id <ACCESS\_KEY\_ID\_2> |

•CloudTrail Logs

# Look for recent API calls made with each access key

|  |
| --- |
| aws logs filter-log-events --log-group-name CloudTrail/APIGateway \  --filter-pattern "{ $.userIdentity.accessKeyId = \"<ACCESS\_KEY\_ID>\" }" \  --start-time $(date -d '7 days ago' +%s)000 |

### 5.3 Co-ordinate with application teams:

1. Identify which access key is actively used
2. Plan for key rotation if needed
3. Schedule a maintenance window if necessary

### 5.4 Deactivating the unused access key:

# Deactivate the unused access key (replace with actual key ID)

|  |
| --- |
| aws iam update-access-key --user-name <USERNAME> \  --access-key-id <UNUSED\_ACCESS\_KEY\_ID> \  --status Inactive |

### 5.5 Test the application functionality:

# Monitor CloudWatch logs for authentication errors

|  |
| --- |
| aws logs filter-log-events --log-group-name <APPLICATION\_LOG\_GROUP> \  --filter-pattern "ERROR" \  --start-time $(date -d '10 minutes ago' +%s)000 |

### 5.6 Delete the inactive access key:

|  |
| --- |
| aws iam delete-access-key --user-name <USERNAME> \  --access-key-id <INACTIVE\_ACCESS\_KEY\_ID> |

## 6. Mitigation Using CloudFormation (IaC)

CloudFormation remediation is enforced by removing or conditionally controlling access key creation.

YAML:

|  |
| --- |
| Parameters:  CreateAccessKey:  Type: String  AllowedValues:  - true  - false  Default: false  Conditions:  CreateAccessKeyCondition: !Equals [ !Ref CreateAccessKey, true ]  Resources:  IAMUserAccessKey:  Type: AWS::IAM::AccessKey  Condition: CreateAccessKeyCondition  Properties:  UserName: !Ref IAMUser  Status: Active |

## 7. Mitigation Using Terraform (IaC)

Terraform is used when IAM users and access keys are managed as code.

Since Terraform **cannot** directly deactivate an access key, remediation is implemented by:

* Ensuring only ONE aws\_iam\_access\_key resource exists
* Removing extra access keys from configuration
* Re-applying Terraform to enforce the desired state

### 7.1 Enforce Single Active Access Key

Define only one access key resource per IAM user.

Terraform

|  |
| --- |
| resource "aws\_iam\_user" "user" {  name = "example-user"  }  resource "aws\_iam\_access\_key" "user\_key" {  user = aws\_iam\_user.user.name  } |

This ensures:

Only one key is managed

Terraform prevents creation of multiple keys

### 7.2 Remove Additional Access Keys

If multiple keys exist:

Step 1: Identify extra keys (outside Terraform)

From Wiz finding or AWS console

Step 2: Update Terraform

If you previously had multiple keys like:

Terraform

|  |
| --- |
| resource "aws\_iam\_access\_key" "key1" {  user = aws\_iam\_user.user.name  }  resource "aws\_iam\_access\_key" "key2" {  user = aws\_iam\_user.user.name  } |

Remove one resource

Terraform

|  |
| --- |
| resource "aws\_iam\_access\_key" "key1" {  user = aws\_iam\_user.user.name  } |

Terraform will delete the extra key on apply

### 7.3 Conditional Key Creation (Best Practice)

Control access key creation using variables:

Terraform

|  |
| --- |
| variable "create\_access\_key" {  ]  type = bool  default = true  }  resource "aws\_iam\_access\_key" "this" {  count = var.create\_access\_key ? 1 : 0  user = aws\_iam\_user.user.name  } |

### 7.4 Key Rotation Strategy (Recommended)

Instead of keeping 2 active keys:

1. Create new key (temporary overlap)
2. Update application with new key
3. Remove old key from Terraform
4. Apply changes

Ensures:

No downtime

Compliance maintained

## 8: Document Exception

Limiting IAM users to a single active access key is essential for reducing security risks, simplifying audits, and ensuring compliance. By following this runbook and leveraging tools like Wiz.io, organizations can effectively manage access keys and maintain a robust security posture.

In Wiz: Add exception notes to the finding and set a periodic review reminder.

Required documentation:

* Business justification
* Approver name and date
* Exception expiry date
* Compensating controls (restricted policy, monitoring, rotation)

## 9. Preventive Control – AWS Config Managed Rule

1. 1.Implement Access Key Rotation Policy
2. Use IAM Roles Instead of Access Keys
3. Monitor Access Key Usage
4. Implement Least Privilege Access

## 10. Validation and Success Criteria

Successful remediation is confirmed when:

* Wiz findings for this metric are reduced to zero
* Each IAM user has no more than one active access key
* Approved exceptions are documented and reviewed periodically