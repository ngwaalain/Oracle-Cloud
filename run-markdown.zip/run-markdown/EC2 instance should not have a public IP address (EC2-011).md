![A green leaf on a black background

AI-generated content may be incorrect.](data:image/png;base64...)

**Cloud Security Posture Management**

**Runbook – Remediation**

|  |  |  |
| --- | --- | --- |
| **Control Id** | **Control Name** | **Severity** |
| **EC2-011** | **EC2 instance should not have a public IP address.** | **High** |

Version 1.0

**Table of Contents**

[1. Overview 3](#_Toc229739285)

[2. Objective 3](#_Toc229739286)

[3. Triage Process 4](#_Toc229739287)

[3.1. Identify Affected Users (Wiz) 4](#_Toc229739288)

[3.2. Categorization 4](#_Toc229739289)

[4. Manual Mitigation – AWS Console 4](#_Toc229739290)

[4.1. Detach Public IP (Primary Remediation) 4](#_Toc229739291)

[4.2. Verify and Validate 6](#_Toc229739292)

[5. Mitigation – AWS CLI 6](#_Toc229739293)

[6. Mitigation Using CloudFormation (IaC) 9](#_Toc229739294)

[7. Mitigation using Teraform 11](#_Toc229739295)

[8. Document Exception 12](#_Toc229739296)

[9. Detective Control 12](#_Toc229739297)

[10. Validation and Success Criteria 12](#_Toc229739298)

# Overview

**Detection Tool**: Wiz Cloud Security Platform

**Hyperlink to the Rule**: [Cloud Configuration Findings | Wiz](https://app.wiz.io/findings/configuration-findings/cloud#%7E%28filters%7E%28status%7E%28equals%7E%28%7E%27OPEN%29%29%7Erule%7E%28equals%7E%28%7E%278f789000-e741-4e83-ba0f-bc5927616c55%29%29%29%7Eentity%7E%28%7E%29%7EcloudConfigurationRule%7E%278f789000-e741-4e83-ba0f-bc5927616c55%29)

**Description**

This control identifies Amazon EC2 instances that are assigned to public IPv4 addresses, making them directly reachable from the internet. Public IP exposure significantly increases the attack surface, especially when instances are not intentionally designed to be internet‑facing.

EC2 instances with public IPs may be exposed to threats such as unauthorized access, brute‑force attacks, vulnerability exploitation, and data exfiltration if adequate network controls (security groups, NACLs, WAF, hardening) are not in place. Unintended public exposure is a common root cause of cloud security incidents.

This control enforces network segmentation and least‑exposure principles, ensuring EC2 instances are placed in private subnets and accessed via secure mechanisms such as load balancers, bastion hosts, VPNs, or AWS Systems Manager Session Manager.

This is detective control. Wiz evaluates EC2 networking configuration (subnet routing, public IP association, and internet gateway attachment) to identify instances that are publicly accessible.

# Objective

The objective of this runbook is to define a standardized approach to identify, validate, and remediate EC2 instances that have public IP addresses, as detected by the Wiz Cloud Security Platform.

This runbook provides guidance to:

* Confirm whether public exposure is intentional
* Identify business ownership and workload criticality
* Safely remove public IP exposure
* Apply approved exceptions with compensating controls

The goal is to ensure that all EC2 instances are private by default, with public exposure allowed only for explicitly approved, well‑secured workloads.

# Triage Process

Please Refer to the below mentioned document:

[Master+Template+-+Remediation+SOP.docx](https://cargillonline.sharepoint.com/%3Aw%3A/r/sites/GIS-ADC-CloudSecurityTeam-TeamDiscussions-Private/_layouts/15/Doc.aspx?sourcedoc=%7B78D12AE6-08C4-4A84-AB4A-348A3A0F0F82%7D&file=Master%2BTemplate%2B-%2BRemediation%2BSOP.docx&action=default&mobileredirect=true)

## Identify Affected Users (Wiz)

Navigate to Wiz → Cloud Configuration Findings and filter by the rule “EC2 instance should not have a public IP address”.

Export the affected resources and capture:

* Instance ID
* AWS Account ID
* Subnet ID
* Public IP address
* VPC and route table details
* Business owner / application tags

## Categorization

**Safe to Remediate**: Internal workloads, backend services, databases, batch jobs

**Requires Investigation**: Legacy applications, unknown ownership, third‑party integrations

**Approved Public Exposure (Exceptions)**: Web servers, ALB/NLB targets, bastion hosts

**Note**: Always validate whether the instance is intentionally internet‑facing and whether exposure is via a public IP directly or through a load balancer.

# Manual Mitigation – AWS Console

## Detach Public IP (Primary Remediation)

Access the EC2 Console

1. Log into the AWS Management Console
2. Navigate to Services → EC2 or search for "EC2" in the search bar
3. Click on EC2 to open the EC2 Dashboard

Locate the EC2 Instance

1. In the left navigation pane, click on Instances
2. Look for the instance with ID
3. You can use the search/filter bar to quickly find the instance by entering the fleet ID

Check Current Public IP Configuration

1. Select the instance by clicking on its checkbox
2. In the Details tab below, look for:
   * Public IPv4 address field
   * Public IPv4 DNS field
3. Note the current public IP address for reference

Remove Public IP Address

**Option A**: Disassociate Elastic IP (if applicable)

* Select the instance
* Click Actions → Networking → Disassociate Elastic IP address
* In the dialog box, confirm the disassociation
* Click Disassociate

Stop and Modify Instance (for instances with auto-assigned public IPs)

1. Stop the instance first:
   * Select the instance
   * Click Instance state → Stop instance
   * Wait for the instance state to change to "Stopped"
2. Modify the instance:
   * With the stopped instance selected, click Actions → Networking → Change subnet
   * Choose a private subnet (one without auto-assign public IP enabled)
   * Click Change subnet
3. Alternative - Modify subnet settings:
   * Go to VPC service in AWS Console
   * Click on Subnets in the left navigation
   * Find and select the subnet where your instance resides
   * Click Actions → Modify auto-assign IP settings
   * Uncheck Enable auto-assign public IPv4 address
   * Click Save

## Verify and Validate

Restart the Instance (if stopped)

1. Select the instance
2. Click Instance state → Start instance
3. Wait for the instance to reach "Running" state

Verify Configuration

1. Select the instance and check the Details tab
2. Confirm that:
   * Public IPv4 address field shows "—" or is empty
   * Public IPv4 DNS field shows "—" or is empty
3. The instance should now only have a private IP address

# Mitigation – AWS CLI

Verify Current Configuration

First, let's identify and verify the current state of the EC2 instance:

# Extract the fleet ID from the resource ID

|  |
| --- |
| FLEET\_ID="resource ID" |

# Get instances associated with the fleet

|  |
| --- |
| aws ec2 describe-instances \  --filters "Name=tag:aws:ec2fleet:fleet-id,Values=$FLEET\_ID" \  --query 'Reservations[].Instances[].[InstanceId,PublicIpAddress,State.Name]' \  --output table |

* Alternative method if the above doesn't return results:

# Search for instances with public IP addresses

|  |
| --- |
| aws ec2 describe-instances \  --filters "Name=instance-state-name,Values=running" \  --query 'Reservations[].Instances[?PublicIpAddress!=null].[InstanceId,PublicIpAddress,Tags[?Key==`Name`].Value|[0]]' \  --output table |

* Identify the Specific Instance

# Store the instance ID for further operations

|  |
| --- |
| INSTANCE\_ID=$(aws ec2 describe-instances \  --filters "Name=tag:aws:ec2fleet:fleet-id,Values=$FLEET\_ID" \  --query 'Reservations[].Instances[].InstanceId' \  --output text)  echo "Instance ID: $INSTANCE\_ID" |

# Verify the instance has a public IP

|  |
| --- |
| aws ec2 describe-instances \  --instance-ids $INSTANCE\_ID \  --query 'Reservations[].Instances[].[InstanceId,PublicIpAddress,PublicDnsName]' \  --output table |

Remove Public IP Address

**Note**: You cannot directly remove a public IP from a running instance

# The instance needs to be stopped and started (not rebooted)

echo "Warning: To remove public IP, the instance must be stopped and started"

Stop and Start Instance (Recommended approach)

# Stop the instance

|  |
| --- |
| echo "Stopping instance $INSTANCE\_ID..."  aws ec2 stop-instances --instance-ids $INSTANCE\_ID |

# Wait for instance to stop

|  |
| --- |
| echo "Waiting for instance to stop..."  aws ec2 wait instance-stopped --instance-ids $INSTANCE\_ID |

# Verify instance is stopped

|  |
| --- |
| aws ec2 describe-instances \  --instance-ids $INSTANCE\_ID \  --query 'Reservations[].Instances[].State.Name' \  --output text |

# Start the instance (When an instance is restart/start and if public ip auto-assign is disabled then a new private ip is assigned from the subnet)

|  |
| --- |
| echo "Starting instance $INSTANCE\_ID..."  aws ec2 start-instances --instance-ids $INSTANCE\_ID |

# Wait for instance to start

echo "Waiting for instance to start..."

|  |
| --- |
| aws ec2 wait instance-running --instance-ids $INSTANCE\_ID |

Prevent Future Public IP Assignment

Modify Subnet Settings (if applicable)

# Get the subnet ID of the instance

|  |
| --- |
| SUBNET\_ID=$(aws ec2 describe-instances \  --instance-ids $INSTANCE\_ID \  --query 'Reservations[].Instances[].SubnetId' \  --output text)  echo "Subnet ID: $SUBNET\_ID" |

# Disable auto-assign public IP for the subnet

|  |
| --- |
| aws ec2 modify-subnet-attribute \  --subnet-id $SUBNET\_ID \  --no-map-public-ip-on-launch  echo "Disabled auto-assign public IP for subnet $SUBNET\_ID" |

# Mitigation Using CloudFormation (IaC)

*Mention the main part of the code here*

Modify Existing EC2 Instance (Recommended)

* Wiz identifies EC2 instance with public IP
* Confirm instance is CloudFormation‑managed
* Update template:
  + AssociatePublicIpAddress: false
  + Move instance to **private subnet**
* Redeploy stack (instance replacement may occur)
* Validate network exposure

|  |
| --- |
| AssociatePublicIpAddress: false |
| Eg:  **Using subnet level**  Resources:    PrivateSubnet:      Type: AWS::EC2::Subnet      Properties:        VpcId: !Ref MyVPC        CidrBlock: 10.0.1.0/24        AvailabilityZone: ap-south-1a        # Critical setting        MapPublicIpOnLaunch: false  **At Instance level**  Resources:  LaunchTemplate:  Type: AWS::EC2::LaunchTemplate  Properties:  LaunchTemplateData:  ImageId: ami-xxxxxxxx  InstanceType: t3.micro    NetworkInterfaces:  - DeviceIndex: 0  AssociatePublicIpAddress: false |

Validation Steps

1. Verify No Public IP: Check that AssociatePublicIpAddress is set to false
2. Test Connectivity: Ensure the instance can reach required services through NAT Gateway
3. Validate Security Groups: Confirm security groups only allow necessary traffic
4. Check Access Methods: Verify bastion host or SSM Session Manager access works

# Mitigation using Teraform

Prevent EC2 instances from receiving public IPs using:

* Subnet configuration
* Network interface settings

Eg:

|  |
| --- |
| At subnet level  resource "aws\_subnet" "private\_subnet" {  vpc\_id = aws\_vpc.main.id  cidr\_block = "10.0.1.0/24"  availability\_zone = "ap-south-1a"    # Critical setting  map\_public\_ip\_on\_launch = false  }  At Instance level  resource "aws\_instance" "secure\_instance" {    ami                         = "ami-xxxxxxxx"    instance\_type               = "t3.micro"    subnet\_id                   = aws\_subnet.private\_subnet.id      # Critical setting    associate\_public\_ip\_address = false  } |

# Document Exception

Use when public IP exposure is business‑justified.

Required documentation:

* Business justification
* Instance purpose
* Approver name and date
* Exception expiry date
* Compensating controls (restricted SGs, MFA access, monitoring)

# Detective Control

AWS Config provides limited native detection for public IP exposure. Wiz continuously evaluates:

* Instance network interfaces
* Public IP association
* Subnet routing to Internet Gateway

Findings are generated for remediation review.

# Validation and Success Criteria

Successful remediation is confirmed when:

* EC2 instances no longer have public IPs
* Wiz findings are resolved or exception‑approved
* Access paths follow approved network architecture