# Solaris Exporter Ansible Deployment

This repository deploys and validates the `solaris_exporter` service on Solaris hosts for Prometheus-compatible consumers (including Dynatrace integrations).

## Repository Layout

- `playbooks/install.yml`: Installs and validates exporter + SMF service.
- `playbooks/uninstall.yml`: Removes exporter service and files.
- `playbooks/smoke-test.yml`: Basic connectivity and file operation checks.
- `roles/solaris_exporter/`: Reusable role with defaults, tasks, files, and templates.
- `inventories/example/hosts.ini`: Safe example inventory.
- `inventories/prod/group_vars/solaris.yml`: Environment variables for production inventory.

## Quick Start

1. Copy the example inventory and update host values:

   `cp inventories/example/hosts.ini inventories/prod/hosts.ini`

2. Update variables if needed in `inventories/prod/group_vars/solaris.yml`.

3. Run install:

   `ansible-playbook -i inventories/prod/hosts.ini playbooks/install.yml -vv`

4. Run uninstall:

   `ansible-playbook -i inventories/prod/hosts.ini playbooks/uninstall.yml -vv`

## Health Validation

The role validates:

- Python dependency availability (`prometheus_client`, `psutil`)
- SMF service registration/import
- Port availability (`9100` by default)
- Metrics endpoint response (`/metrics`)

Note: On some Solaris versions, SMF may show `offline*` while the process and endpoint are healthy. Functional validation checks are included in the install workflow.

## Backward Compatibility

Legacy root playbooks (`validate-install.yaml`, `validate-uninstall.yaml`, `solaris-1.yaml`) are kept as wrappers that import the new playbooks.
